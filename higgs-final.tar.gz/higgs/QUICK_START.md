# Higgs - Guia Rápido

## 1️⃣ Instalar dependências

```bash
cd higgs
npm install
```

## 2️⃣ Escolher o motor de IA

Crie uma chave de API grátis num destes provedores:
- **Groq** (recomendado, mais rápido): console.groq.com/keys
- **Mistral**: console.mistral.ai/api-keys
- **DeepSeek**: platform.deepseek.com/api_keys

Abra o app, vá em ⚙️ Configurações → aba "IA", escolha o provedor e cole a
chave. Clique em "Testar conexão" pra confirmar.

**Dica:** configure duas chaves (ex: Groq + Mistral) — se uma cair, o Higgs
troca pra outra sozinho.

## 3️⃣ Rodar o Higgs

```bash
npm run dev
```

## 4️⃣ Usar

- **Digite** sua pergunta, segure o 🎤 para falar (precisa de chave do Groq
  configurada), ou clique no 📷 pra perguntar sobre o que está na tela
- **➕** começa uma conversa nova
- **💾** abre o histórico — clique numa conversa para recarregá-la, ou exporte/apague
- **⚙️** troca de provedor de IA, personalidade, voz e mais

## 🆘 Problemas comuns

**"Configure a chave de API..."**
- Abra ⚙️ Configurações → aba "IA" e cole a chave do provedor escolhido

**Microfone não funciona**
- Precisa de uma chave do Groq configurada (mesmo usando outro provedor pra conversar)
- Confira permissões de microfone do sistema operacional

**Atalho de teclado não responde**
- Pode estar em conflito com outro programa — o app avisa quando isso
  acontece. Troque o atalho em ⚙️ Configurações → Sistema

---
Pronto! Higgs rodando com sua própria chave de API. 🎯
