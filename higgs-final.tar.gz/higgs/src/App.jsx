import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, Send, Settings, Trash2, Save, Plus, Download, Upload, Volume2, VolumeX, Copy, Check, ExternalLink, Minus, Square, X, Camera, Paperclip, FileText } from 'lucide-react';
import HUD from './components/HUD';
import Dashboard from './components/Dashboard';
import ReactorCore from './components/ReactorCore';
import { useVoice } from './hooks/useVoice';
import { storage } from './utils/storage';
import { renderMarkdown } from './utils/markdown';
import './App.css';

const makeWelcome = (name = 'Higgs') => ({ role: 'system', content: `${name} online. À sua disposição, senhor.`, timestamp: Date.now() });

const PROVIDER_LABELS = {
  mistral: 'Mistral (nuvem)',
  groq: 'Groq (nuvem)',
  deepseek: 'DeepSeek (nuvem)',
};

const PERSONALITIES = {
  sarcastic: { pt: 'Seja breve, elegante e sarcástico.', en: 'Be brief, refined and a touch witty.' },
  formal: { pt: 'Seja extremamente formal, cortês e profissional, como um mordomo britânico.', en: 'Be extremely formal, courteous and professional, like a British butler.' },
  direct: { pt: 'Seja direto, objetivo e conciso, sem rodeios.', en: 'Be direct, objective and concise, no fluff.' },
  friendly: { pt: 'Seja caloroso, amigável e encorajador.', en: 'Be warm, friendly and encouraging.' },
  buddy: { pt: 'Fale de igual para igual, como um amigo próximo de longa data: casual, caloroso, bem-humorado, sem nenhuma formalidade — nunca chame de "senhor", trate como parceiro mesmo.', en: 'Talk like a close old friend: casual, warm, funny, zero formality — never call them "sir", just genuine mate-to-mate energy.' },
};

const PERSONALITY_LABELS = {
  sarcastic: 'Sarcástico',
  formal: 'Formal',
  direct: 'Direto',
  friendly: 'Amigável',
  buddy: 'Amigo pra amigo',
};

const ACCENT_PRESETS = {
  teal: { hex: '#4fd8c4', rgb: '79,216,196', label: 'Teal' },
  purple: { hex: '#a78bfa', rgb: '167,139,250', label: 'Roxo' },
  blue: { hex: '#5b9cf2', rgb: '91,156,242', label: 'Azul' },
  rose: { hex: '#ff6b9d', rgb: '255,107,157', label: 'Rosa' },
};

function apiKeyForProvider(config) {
  return apiKeyForProviderName(config, config.provider);
}

function apiKeyForProviderName(config, provider) {
  if (provider === 'mistral') return config.mistralApiKey;
  if (provider === 'groq') return config.groqApiKey;
  if (provider === 'deepseek') return config.deepseekApiKey;
  return undefined;
}

function modelForProviderName(config, provider) {
  if (provider === 'mistral') return config.mistralModel;
  if (provider === 'groq') return config.groqModel;
  if (provider === 'deepseek') return config.deepseekModel;
  return undefined;
}

function buildSystemPrompt(config) {
  const lang = config.voiceLanguage === 'en' ? 'en' : 'pt';
  const name = config.assistantName || 'Higgs';
  const personalityLine = (PERSONALITIES[config.personality] || PERSONALITIES.sarcastic)[lang];
  const memories = config.memories || [];
  const memoryLine = memories.length
    ? lang === 'en'
      ? ` Important facts about the user you must always remember: ${memories.map((m) => m.text).join('; ')}.`
      : ` Fatos importantes sobre o usuário que você deve sempre lembrar: ${memories.map((m) => m.text).join('; ')}.`
    : '';
  return lang === 'en'
    ? `You are ${name}, an AI assistant. ${personalityLine} Respond in English.${memoryLine}`
    : `Você é o ${name}, um assistente de IA. ${personalityLine} Responda em português.${memoryLine}`;
}

function greetingText(config) {
  const name = config.assistantName || 'Higgs';
  const hour = new Date().getHours();
  const casual = config.personality === 'buddy';

  if (config.voiceLanguage === 'en') {
    const g = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    return casual ? `Hey! ${name} here, ready to go.` : `${g}, sir. ${name} online and at your service.`;
  }
  const g = hour < 6 ? 'Boa madrugada' : hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
  return casual ? `E aí! ${name} on, bora nessa.` : `${g}, senhor. ${name} online e à sua disposição.`;
}

function formatClock(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

export default function App() {
  const [messages, setMessages] = useState(() => [makeWelcome()]);
  const [currentConvId, setCurrentConvId] = useState(null);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [config, setConfigState] = useState(null);
  const [voices, setVoices] = useState([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [conversations, setConversations] = useState([]);
  const [errorBanner, setErrorBanner] = useState('');
  const [copiedIdx, setCopiedIdx] = useState(null);
  const [memoryToast, setMemoryToast] = useState(null);
  const [mobileInfo, setMobileInfo] = useState(null);
  const [autostartEnabled, setAutostartEnabled] = useState(false);
  const [shortcutSaved, setShortcutSaved] = useState(false);
  const [appVersion, setAppVersion] = useState('');
  const [updateState, setUpdateState] = useState({ status: 'idle', version: null, percent: 0, error: null });
  const [settingsTab, setSettingsTab] = useState('perfil');
  const [testingConnection, setTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [attachedScreenshot, setAttachedScreenshot] = useState(null);
  const [attachedTextFile, setAttachedTextFile] = useState(null);
  const backupInputRef = useRef(null);
  const shortcutToggleInputRef = useRef(null);
  const shortcutScreenshotInputRef = useRef(null);
  const [newMemoryText, setNewMemoryText] = useState('');
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const spacePressedRef = useRef(false);
  const [streamingText, setStreamingText] = useState('');
  const currentStreamIdRef = useRef(null);
  const currentPayloadRef = useRef(null);
  const fallbackQueueRef = useRef([]);
  const lastUserTextRef = useRef('');
  const { isListening, isTranscribing, isSpeaking, startListening, stopListening, speak, stopSpeaking, speakAnalyserRef, micAnalyserRef } = useVoice();

  // Respeita o mudo para toda fala automática (respostas, lembretes, saudação).
  // O botão "Testar voz" chama speak() direto, de propósito, mesmo mutado.
  const speakIfEnabled = (text, opts) => {
    if (!config?.voiceMuted) speak(text, opts);
  };

  useEffect(() => {
    (async () => {
      const cfg = await window.electron.config.get();
      setConfigState(cfg);
      const info = await window.electron.mobile.getInfo();
      setMobileInfo(info);
      const autostart = await window.electron.autostart.get();
      setAutostartEnabled(autostart);
      const version = await window.electron.update.getVersion();
      setAppVersion(version);
    })();
    setConversations(storage.getConversations());
  }, []);

  // Recebe o print capturado (atalho global ou botão de câmera) e prepara
  // o campo de texto pra pergunta, com o foco já no lugar certo
  useEffect(() => {
    const unsubCaptured = window.electron.screenshot.onCaptured((data) => {
      setAttachedScreenshot(data);
      setAttachedTextFile(null);
      setErrorBanner('');
      setTimeout(() => textareaRef.current?.focus(), 100);
    });
    const unsubError = window.electron.screenshot.onError((msg) => {
      setErrorBanner('Erro ao capturar a tela: ' + msg);
    });
    const unsubShortcutConflict = window.electron.shortcuts.onConflict((msg) => {
      setErrorBanner(msg);
    });
    const unsubUpdateAvailable = window.electron.update.onAvailable((version) => {
      setUpdateState({ status: 'available', version, percent: 0, error: null });
    });
    const unsubUpdateNotAvailable = window.electron.update.onNotAvailable(() => {
      setUpdateState((prev) => (prev.status === 'checking' ? { status: 'idle', version: null, percent: 0, error: null } : prev));
    });
    const unsubUpdateProgress = window.electron.update.onProgress((percent) => {
      setUpdateState((prev) => ({ ...prev, status: 'downloading', percent }));
    });
    const unsubUpdateReady = window.electron.update.onReady(() => {
      setUpdateState((prev) => ({ ...prev, status: 'ready', percent: 100 }));
    });
    const unsubUpdateError = window.electron.update.onError((message) => {
      setUpdateState((prev) => ({ ...prev, status: 'error', error: message }));
    });
    return () => {
      unsubCaptured();
      unsubError();
      unsubShortcutConflict();
      unsubUpdateAvailable();
      unsubUpdateNotAvailable();
      unsubUpdateProgress();
      unsubUpdateReady();
      unsubUpdateError();
    };
  }, []);

  // Recarrega a lista de vozes quando o idioma muda
  useEffect(() => {
    if (!config) return;
    (async () => {
      const list = await window.electron.tts.voices(config.voiceLanguage || 'pt');
      setVoices(list);
    })();
  }, [config?.voiceLanguage]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing, streamingText]);

  // Sempre aponta pras versões mais recentes dessas funções — evita o efeito
  // clássico de "closure desatualizada" do React em listeners de longa duração.
  const latestRef = useRef({});

  // Atalhos de teclado: Ctrl+N nova conversa, Ctrl+, configurações, Esc fecha painéis,
  // espaço mantido pressionado (fora do campo de texto) = falar por voz
  useEffect(() => {
    const handleKeyDown = (e) => {
      const isTyping = document.activeElement === textareaRef.current;
      const latest = latestRef.current;

      if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        latest.startNewConversation();
      } else if ((e.ctrlKey || e.metaKey) && e.key === ',') {
        e.preventDefault();
        setShowSettings((s) => !s);
      } else if (e.key === 'Escape') {
        setShowSettings(false);
        setShowHistory(false);
      } else if (e.code === 'Space' && !isTyping && !spacePressedRef.current && !latest.isListening) {
        e.preventDefault();
        spacePressedRef.current = true;
        latest.beginRecording();
      }
    };

    const handleKeyUp = (e) => {
      if (e.code === 'Space' && spacePressedRef.current) {
        spacePressedRef.current = false;
        latestRef.current.endRecording();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Ouve os pedaços da resposta chegando (efeito de "digitando"), monta a
  // mensagem final quando termina, e tenta o próximo provedor da fila de
  // fallback automaticamente se o atual falhar no meio do caminho.
  useEffect(() => {
    const unsubChunk = window.electron.ai.onStreamChunk(({ requestId, delta }) => {
      if (requestId !== currentStreamIdRef.current) return;
      setStreamingText((prev) => prev + delta);
    });

    const unsubDone = window.electron.ai.onStreamDone(({ requestId, content }) => {
      if (requestId !== currentStreamIdRef.current) return;
      const latest = latestRef.current;
      setStreamingText('');
      setIsProcessing(false);
      const assistantMsg = { role: 'assistant', content: content || '(resposta vazia)', timestamp: Date.now() };
      setMessages((prev) => {
        const next = [...prev, assistantMsg];
        latest.persistConversation(next);
        return next;
      });
      latest.speakIfEnabled(content, {
        voice: latest.config.ttsVoice,
        rate: latest.config.ttsRate,
        pitch: latest.config.ttsPitch,
        volume: latest.config.ttsVolume,
      });
      latest.maybeAutoRemember(lastUserTextRef.current);
    });

    const unsubError = window.electron.ai.onStreamError(({ requestId, message }) => {
      if (requestId !== currentStreamIdRef.current) return;
      const latest = latestRef.current;

      if (fallbackQueueRef.current.length > 0) {
        const nextProvider = fallbackQueueRef.current.shift();
        const nextModel = modelForProviderName(latest.config, nextProvider);
        const nextKey = apiKeyForProviderName(latest.config, nextProvider);
        setErrorBanner(`${PROVIDER_LABELS[latest.config.provider]} falhou (${message}) — tentando ${PROVIDER_LABELS[nextProvider]}…`);
        latest.startChatStream(nextProvider, nextModel, nextKey, currentPayloadRef.current);
        return;
      }

      setStreamingText('');
      setIsProcessing(false);
      setErrorBanner(message);
      setMessages((prev) => [...prev, { role: 'assistant', content: `Erro: ${message}`, timestamp: Date.now() }]);
    });

    return () => {
      unsubChunk();
      unsubDone();
      unsubError();
    };
  }, []);


  const updateConfig = async (partial) => {
    const saved = await window.electron.config.set(partial);
    setConfigState(saved);
  };

  const addMemory = async (text) => {
    const clean = text.trim();
    if (!clean) return;
    const updated = await window.electron.memory.add(clean);
    setConfigState(updated);
  };

  const removeMemory = async (id) => {
    const updated = await window.electron.memory.remove(id);
    setConfigState(updated);
  };

  // Roda em segundo plano depois de cada resposta normal: pergunta pra
  // própria IA se a mensagem do usuário tem algo que vale guardar pra
  // sempre. Não trava a resposta principal, e não incomoda se falhar.
  const maybeAutoRemember = async (userText) => {
    if (!config.autoMemory || !userText || userText.trim().length < 8) return;
    try {
      const result = await window.electron.ai.chat(
        config.provider,
        activeModel(),
        [
          {
            role: 'system',
            content:
              'Você extrai fatos pessoais duradouros de mensagens de usuários. Se a mensagem a seguir contiver um fato que vale a pena lembrar para sempre (nome, profissão, projeto em andamento, preferência importante, relação, objetivo de vida), responda com esse fato em UMA frase curta e direta, sem comentários nem introdução. Se não houver nada memorável, responda exatamente: NONE.',
          },
          { role: 'user', content: userText },
        ],
        apiKeyForProvider(config)
      );
      const fact = result.message?.content?.trim();
      if (!fact || fact.toUpperCase().startsWith('NONE') || fact.length > 200) return;
      const alreadyKnown = (config.memories || []).some(
        (m) => m.text.toLowerCase() === fact.toLowerCase()
      );
      if (!alreadyKnown) {
        await addMemory(fact);
        setMemoryToast(fact);
        setTimeout(() => setMemoryToast(null), 4000);
      }
    } catch {
      // Falha silenciosa — isso é um bônus em segundo plano, não deve
      // gerar erro visível pro usuário.
    }
  };

  const providerReady = () => {
    if (!config) return false;
    if (config.provider === 'mistral') return !!config.mistralApiKey;
    if (config.provider === 'groq') return !!config.groqApiKey;
    if (config.provider === 'deepseek') return !!config.deepseekApiKey;
    return false;
  };

  const activeModel = () => {
    if (!config) return '';
    if (config.provider === 'mistral') return config.mistralModel;
    if (config.provider === 'groq') return config.groqModel;
    if (config.provider === 'deepseek') return config.deepseekModel;
    return '';
  };

  // Se o provedor escolhido falhar no meio de uma resposta, tenta os outros
  // que já têm chave configurada, nessa ordem de preferência.
  const buildFallbackChain = () => {
    const isReady = (p) => !!apiKeyForProviderName(config, p);
    return ['groq', 'mistral', 'deepseek'].filter((p) => p !== config.provider && isReady(p));
  };

  const aiState = isListening ? 'listening' : (isProcessing || isTranscribing) ? 'thinking' : isSpeaking ? 'speaking' : 'idle';
  const activeAnalyserRef = aiState === 'speaking' ? speakAnalyserRef : aiState === 'listening' ? micAnalyserRef : null;

  const persistConversation = useCallback((allMessages) => {
    const chatMessages = allMessages.filter((m) => m.role !== 'system');
    if (currentConvId) {
      const updated = storage.updateConversation(currentConvId, chatMessages);
      if (updated) {
        setConversations(storage.getConversations());
        return;
      }
    }
    const created = storage.saveConversation(chatMessages);
    if (created) {
      setCurrentConvId(created.id);
      setConversations(storage.getConversations());
    }
  }, [currentConvId]);

  const resizeTextarea = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 140) + 'px';
  };

  useEffect(resizeTextarea, [input]);

  const runLocalCommand = async (raw) => {
    const cmd = raw.trim().toLowerCase();
    const reminderMatch = raw.trim().match(/^\/lembrete\s+(\d+)\s+(.+)/i);

    if (cmd === '/hora') {
      return `São ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}.`;
    }
    if (cmd === '/data') {
      return `Hoje é ${new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}.`;
    }
    if (cmd === '/sistema') {
      const stats = await window.electron.system.stats();
      return `CPU em ${stats.cpuPercent}%, memória em ${stats.ramPercent}% (${stats.ramUsedGB.toFixed(1)} de ${stats.ramTotalGB.toFixed(1)} GB).`;
    }
    if (cmd === '/clima') {
      if (!config.city) return 'Nenhuma cidade configurada. Adicione uma em Configurações.';
      const w = await window.electron.weather.get(config.city);
      if (w?.error) return w.error;
      return `Em ${w.city}: ${w.temp}°C, ${w.description}.`;
    }
    if (reminderMatch) {
      const minutes = parseInt(reminderMatch[1], 10);
      const note = reminderMatch[2];
      setTimeout(() => {
        const text = `⏰ Lembrete: ${note}`;
        const msg = { role: 'assistant', content: text, timestamp: Date.now() };
        setMessages((prev) => {
          const next = [...prev, msg];
          persistConversation(next);
          return next;
        });
        window.electron.notify.show(config.assistantName || 'Higgs', text);
        speakIfEnabled(text, { voice: config.ttsVoice, rate: config.ttsRate, pitch: config.ttsPitch, volume: config.ttsVolume });
      }, minutes * 60 * 1000);
      return `Combinado — te lembro de "${note}" em ${minutes} minuto${minutes === 1 ? '' : 's'}.`;
    }
    const lembrarMatch = raw.trim().match(/^\/lembrar\s+(.+)/i);
    if (lembrarMatch) {
      await addMemory(lembrarMatch[1]);
      return `Guardado. Vou lembrar disso em todas as conversas: "${lembrarMatch[1].trim()}".`;
    }
    if (cmd === '/memoria') {
      const mem = config.memories || [];
      if (!mem.length) return 'Não tenho nada guardado ainda. Use /lembrar <fato> para eu guardar algo.';
      return `O que eu lembro sobre você:\n${mem.map((m, i) => `${i + 1}. ${m.text}`).join('\n')}`;
    }
    const esquecerMatch = raw.trim().match(/^\/esquecer\s+(\d+)/i);
    if (esquecerMatch) {
      const idx = parseInt(esquecerMatch[1], 10) - 1;
      const mem = config.memories || [];
      if (idx < 0 || idx >= mem.length) return 'Número inválido. Use /memoria para ver a lista numerada.';
      const removed = mem[idx];
      await removeMemory(removed.id);
      return `Esqueci: "${removed.text}".`;
    }
    if (cmd === '/ajuda') {
      return 'Comandos disponíveis: /hora · /data · /clima · /sistema · /lembrete <min> <texto> · /lembrar <fato> · /memoria · /esquecer <nº> · /limpar · /ajuda.';
    }
    return undefined;
  };

  const processMessage = async (text) => {
    const trimmed = text.trim();
    if (!trimmed || isProcessing) return;
    setErrorBanner('');

    // Comandos locais: respondem na hora, sem passar pela IA
    if (trimmed.startsWith('/')) {
      if (trimmed.toLowerCase() === '/limpar') {
        startNewConversation();
        return;
      }
      const userMsg = { role: 'user', content: trimmed, timestamp: Date.now() };
      setMessages((prev) => [...prev, userMsg]);
      setInput('');
      const reply = (await runLocalCommand(trimmed)) ?? 'Comando não reconhecido. Digite /ajuda para ver os comandos.';
      const assistantMsg = { role: 'assistant', content: reply, timestamp: Date.now() };
      setMessages((prev) => {
        const next = [...prev, assistantMsg];
        persistConversation(next);
        return next;
      });
      speakIfEnabled(reply, { voice: config.ttsVoice, rate: config.ttsRate, pitch: config.ttsPitch, volume: config.ttsVolume });
      return;
    }

    if (!providerReady()) return;

    // Pergunta sobre um print anexado (atalho de captura ou botão de câmera)
    if (attachedScreenshot) {
      const screenshotForSend = attachedScreenshot.dataUrl;
      setAttachedScreenshot(null);

      if (config.provider === 'deepseek') {
        setErrorBanner('O DeepSeek ainda não processa imagens. Troque pra Groq ou Mistral em Configurações pra usar prints.');
        return;
      }

      const userMsg = { role: 'user', content: text, image: screenshotForSend, timestamp: Date.now() };
      setMessages((prev) => [...prev, userMsg]);
      setInput('');
      setIsProcessing(true);

      try {
        const visionModel = activeModel();
        const result = await window.electron.ai.chatVision(
          config.provider,
          visionModel,
          text,
          screenshotForSend,
          apiKeyForProvider(config)
        );
        const response = result.message?.content || 'Erro na resposta.';
        const assistantMsg = { role: 'assistant', content: response, timestamp: Date.now() };
        setMessages((prev) => {
          const next = [...prev, assistantMsg];
          persistConversation(next);
          return next;
        });
        setIsProcessing(false);
        speakIfEnabled(response, { voice: config.ttsVoice, rate: config.ttsRate, pitch: config.ttsPitch, volume: config.ttsVolume });
      } catch (error) {
        setErrorBanner(error.message);
        setMessages((prev) => [...prev, { role: 'assistant', content: `Erro: ${error.message}`, timestamp: Date.now() }]);
        setIsProcessing(false);
      }
      return;
    }

    const fileForSend = attachedTextFile;
    setAttachedTextFile(null);

    const userMsg = { role: 'user', content: text, timestamp: Date.now(), fileName: fileForSend?.name };
    const historyForModel = [...messages, userMsg].filter((m) => m.role !== 'system');
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsProcessing(true);
    setStreamingText('');
    lastUserTextRef.current = text;

    const payloadMessages = [
      { role: 'system', content: buildSystemPrompt(config) },
      ...historyForModel.map(({ role, content }) => ({ role, content })),
    ];

    // O conteúdo do arquivo vai só pro modelo, não polui a bolha da mensagem
    // exibida — a pessoa só vê o nome do arquivo anexado.
    if (fileForSend) {
      const last = payloadMessages[payloadMessages.length - 1];
      last.content = `Arquivo anexado "${fileForSend.name}":\n\`\`\`\n${fileForSend.content}\n\`\`\`\n\nPergunta do usuário: ${text}`;
    }

    fallbackQueueRef.current = buildFallbackChain();
    currentPayloadRef.current = payloadMessages;
    startChatStream(config.provider, activeModel(), apiKeyForProvider(config), payloadMessages);
  };

  // Dispara um stream de resposta. Se falhar e ainda houver provedores na
  // fila de fallback, tenta o próximo automaticamente antes de desistir.
  const startChatStream = (provider, model, apiKey, payloadMessages) => {
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    currentStreamIdRef.current = requestId;
    window.electron.ai.chatStream({ requestId, provider, model, messages: payloadMessages, apiKey });
  };

  const startNewConversation = () => {
    setMessages([makeWelcome(config?.assistantName)]);
    setCurrentConvId(null);
    setInput('');
    setErrorBanner('');
    setShowHistory(false);
  };

  const loadConversation = (conv) => {
    setMessages([makeWelcome(config?.assistantName), ...conv.messages]);
    setCurrentConvId(conv.id);
    setShowHistory(false);
  };

  const testVoice = () => {
    if (!config) return;
    const sample = config.voiceLanguage === 'en' ? 'Testing the voice. Good day, sir.' : 'Testando a voz. Bom dia, senhor.';
    speak(sample, { voice: config.ttsVoice, rate: config.ttsRate, pitch: config.ttsPitch, volume: config.ttsVolume });
  };

  const copyMessage = (text, idx) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 1500);
  };

  const [conversationCopied, setConversationCopied] = useState(false);
  const copyWholeConversation = () => {
    const text = messages
      .filter((m) => m.role !== 'system')
      .map((m) => `${m.role === 'user' ? 'Você' : config.assistantName || 'Higgs'}: ${m.content}`)
      .join('\n\n');
    navigator.clipboard.writeText(text);
    setConversationCopied(true);
    setTimeout(() => setConversationCopied(false), 1500);
  };

  // ------------------------------------------------------------------ //
  // Microfone: apertar e falar (mousedown/touchstart inicia, soltar para)
  // ------------------------------------------------------------------ //
  const beginRecording = () => {
    if (isProcessing || isListening || isTranscribing || !providerReady()) return;
    startListening(
      (text) => processMessage(text),
      config?.groqApiKey,
      (msg) => setErrorBanner(msg)
    );
  };

  const endRecording = () => {
    if (isListening) stopListening();
  };

  latestRef.current = {
    beginRecording,
    endRecording,
    startNewConversation,
    isListening,
    config,
    speakIfEnabled,
    persistConversation,
    maybeAutoRemember,
    startChatStream,
  };

  const openGroqSignup = () => window.electron.shell.openExternal('https://console.groq.com/keys');
  const openDeepseekSignup = () => window.electron.shell.openExternal('https://platform.deepseek.com/api_keys');
  const openMistralSignup = () => window.electron.shell.openExternal('https://console.mistral.ai/api-keys');

  const testConnection = async () => {
    const key = apiKeyForProvider(config);
    if (!key) {
      setTestResult({ ok: false, message: 'Configure uma chave de API primeiro.' });
      return;
    }
    setTestingConnection(true);
    setTestResult(null);
    try {
      const result = await window.electron.ai.chat(
        config.provider,
        activeModel(),
        [{ role: 'user', content: 'Responda apenas com a palavra: ok' }],
        key
      );
      setTestResult({ ok: true, message: `Conectado. O modelo "${activeModel()}" respondeu certinho.` });
    } catch (error) {
      setTestResult({ ok: false, message: error.message });
    } finally {
      setTestingConnection(false);
    }
  };

  const takeScreenshot = () => window.electron.screenshot.trigger();

  const attachFile = async () => {
    try {
      const result = await window.electron.file.attach();
      if (!result) return;
      setErrorBanner('');
      if (result.kind === 'image') {
        setAttachedScreenshot({ dataUrl: result.dataUrl, displayIndex: 0, displayCount: 1, fileName: result.name });
        setAttachedTextFile(null);
      } else {
        setAttachedTextFile({ name: result.name, content: result.content });
        setAttachedScreenshot(null);
      }
      setTimeout(() => textareaRef.current?.focus(), 100);
    } catch (error) {
      setErrorBanner('Erro ao anexar arquivo: ' + error.message);
    }
  };

  const switchCapturedDisplay = async () => {
    if (!attachedScreenshot) return;
    const nextIndex = (attachedScreenshot.displayIndex + 1) % attachedScreenshot.displayCount;
    try {
      const data = await window.electron.screenshot.captureDisplay(nextIndex);
      setAttachedScreenshot(data);
    } catch (error) {
      setErrorBanner('Erro ao trocar de tela: ' + error.message);
    }
  };

  const saveShortcuts = async (toggle, screenshotKey) => {
    const result = await window.electron.shortcuts.update(toggle, screenshotKey);
    setConfigState((prev) => ({ ...prev, shortcutToggle: result.shortcutToggle, shortcutScreenshot: result.shortcutScreenshot }));
    setShortcutSaved(true);
    setTimeout(() => setShortcutSaved(false), 2500);
  };

  const checkForUpdate = async () => {
    setUpdateState({ status: 'checking', version: null, percent: 0, error: null });
    const result = await window.electron.update.check();
    if (result?.error) {
      setUpdateState({ status: 'error', version: null, percent: 0, error: result.error });
    }
  };

  const downloadUpdate = () => {
    setUpdateState((prev) => ({ ...prev, status: 'downloading', percent: 0 }));
    window.electron.update.download();
  };

  const installUpdate = () => window.electron.update.install();

  const exportFullBackup = () => {
    const data = {
      type: 'higgs-backup',
      exportedAt: new Date().toISOString(),
      config,
      conversations: storage.getConversations(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `higgs-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const importFullBackup = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target.result);
        if (data.config) {
          const saved = await window.electron.config.set(data.config);
          setConfigState(saved);
          if (data.config.shortcutToggle || data.config.shortcutScreenshot) {
            await window.electron.shortcuts.update(saved.shortcutToggle, saved.shortcutScreenshot);
          }
        }
        if (Array.isArray(data.conversations)) {
          localStorage.setItem('jarvis_conversations', JSON.stringify(data.conversations));
          setConversations(storage.getConversations());
        }
        const [mobileInfoResult, autostartResult] = await Promise.all([
          window.electron.mobile.getInfo(),
          window.electron.autostart.get(),
        ]);
        setMobileInfo(mobileInfoResult);
        setAutostartEnabled(autostartResult);
        setMemoryToast('Backup restaurado com sucesso.');
        setTimeout(() => setMemoryToast(null), 4000);
      } catch (err) {
        setErrorBanner('Backup inválido: ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  const toggleMobileAccess = async () => {
    const info = await window.electron.mobile.setEnabled(!mobileInfo?.enabled);
    setMobileInfo(info);
  };

  const regenerateMobilePin = async () => {
    const result = await window.electron.mobile.regeneratePin();
    setMobileInfo((prev) => ({ ...prev, pin: result.pin }));
  };

  const [bootReady, setBootReady] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setBootReady(true), 1600);
    return () => clearTimeout(timer);
  }, []);

  const hasGreetedRef = useRef(false);
  useEffect(() => {
    if (config && bootReady && !hasGreetedRef.current) {
      hasGreetedRef.current = true;
      speakIfEnabled(greetingText(config), { voice: config.ttsVoice, rate: config.ttsRate, pitch: config.ttsPitch, volume: config.ttsVolume });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config, bootReady]);

  if (!config || !bootReady) {
    return (
      <div className="jarvis-container loading-screen">
        <ReactorCore state="thinking" analyserRef={null} size={72} />
        <div className="boot-log">
          <p className="boot-line" style={{ animationDelay: '0s' }}>NÚCLEO DE IA · ONLINE</p>
          <p className="boot-line" style={{ animationDelay: '0.35s' }}>RECONHECIMENTO DE VOZ · PRONTO</p>
          <p className="boot-line" style={{ animationDelay: '0.7s' }}>SÍNTESE DE VOZ NEURAL · PRONTA</p>
          <p className="boot-line boot-final" style={{ animationDelay: '1.1s' }}>SISTEMA {(config?.assistantName || 'Higgs').toUpperCase()} OPERACIONAL</p>
        </div>
      </div>
    );
  }

  const accent = ACCENT_PRESETS[config.accentColor] || ACCENT_PRESETS.teal;

  return (
    <div className="jarvis-container" style={{ '--teal': accent.hex }}>
      <div className={`ambient-glow ambient-${aiState}`} />
      <div className="floating-orb" title={aiState}>
        <ReactorCore state={aiState} analyserRef={activeAnalyserRef} size={84} accentHex={accent.hex} accentRgb={accent.rgb} />
      </div>

      {memoryToast && (
        <div className="memory-toast">🧠 Memória atualizada: {memoryToast}</div>
      )}

      <header className="jarvis-header">
        <div className="header-left">
          <span className={`status-dot ${providerReady() ? 'on' : 'off'}`} />
          <div className="header-title-block">
            <h1 className="jarvis-title">{(config.assistantName || 'Higgs').toUpperCase()}</h1>
            <span className="status-text">{PROVIDER_LABELS[config.provider]}</span>
          </div>
        </div>
        <div className="header-buttons">
          <button className="icon-btn" onClick={startNewConversation} title="Nova conversa (Ctrl+N)">
            <Plus size={18} />
          </button>
          <button className="icon-btn" onClick={copyWholeConversation} title="Copiar conversa">
            {conversationCopied ? <Check size={18} /> : <Copy size={18} />}
          </button>
          <button
            className={`icon-btn ${config.voiceMuted ? 'active' : ''}`}
            onClick={() => {
              const next = !config.voiceMuted;
              updateConfig({ voiceMuted: next });
              if (next) stopSpeaking();
            }}
            title={config.voiceMuted ? 'Ativar voz' : 'Mutar voz'}
          >
            {config.voiceMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
          <button className="icon-btn" onClick={() => setShowHistory(!showHistory)} title="Histórico">
            <Save size={18} />
          </button>
          <button className="icon-btn" onClick={() => setShowSettings(!showSettings)} title="Configurações (Ctrl+,)" style={{ position: 'relative' }}>
            <Settings size={18} />
            {(updateState.status === 'ready' || updateState.status === 'available') && <span className="update-badge" />}
          </button>
          <span className="header-divider" />
          <button className="icon-btn window-ctrl" onClick={() => window.electron.window.minimize()} title="Minimizar">
            <Minus size={15} />
          </button>
          <button className="icon-btn window-ctrl" onClick={() => window.electron.window.maximize()} title="Maximizar">
            <Square size={13} />
          </button>
          <button className="icon-btn window-ctrl close" onClick={() => window.electron.window.close()} title="Fechar">
            <X size={16} />
          </button>
        </div>
      </header>

      <Dashboard
        city={config.city}
        personality={config.personality}
        onOpenSettings={() => {
          setSettingsTab('sistema');
          setShowSettings(true);
        }}
      />

      <HUD
        status={providerReady() ? 'online' : 'offline'}
        model={activeModel()}
        messageCount={messages.filter((m) => m.role !== 'system').length}
        aiState={aiState}
      />

      {showHistory && (
        <div className="panel">
          <div className="panel-header">
            <h3>Histórico de Conversas</h3>
            <div>
              <button className="ghost-btn" onClick={() => storage.exportConversations()} title="Exportar">
                <Download size={15} />
              </button>
              <button
                className="ghost-btn"
                onClick={() => {
                  if (confirm('Limpar todo o histórico?')) {
                    storage.clearAll();
                    setConversations([]);
                    startNewConversation();
                  }
                }}
                title="Limpar histórico"
              >
                <Trash2 size={15} />
              </button>
            </div>
          </div>
          <div className="panel-list">
            {conversations.length === 0 ? (
              <div className="empty-state">Nenhuma conversa salva</div>
            ) : (
              conversations.map((conv) => (
                <div key={conv.id} className="list-item">
                  <div className="list-item-info" onClick={() => loadConversation(conv)}>
                    <div className="list-item-title">{conv.title}</div>
                    <div className="list-item-meta">
                      {new Date(conv.timestamp).toLocaleDateString('pt-BR')} · {conv.messageCount} mensagens
                    </div>
                  </div>
                  <button
                    className="ghost-btn"
                    onClick={() => {
                      storage.deleteConversation(conv.id);
                      setConversations(storage.getConversations());
                      if (conv.id === currentConvId) startNewConversation();
                    }}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {showSettings && (
        <div className="panel settings-panel">
          <div className="settings-tabs">
            {[
              ['perfil', 'Perfil'],
              ['ia', 'IA'],
              ['voz', 'Voz'],
              ['memoria', 'Memória'],
              ['sistema', 'Sistema'],
            ].map(([key, label]) => (
              <button
                key={key}
                className={`settings-tab ${settingsTab === key ? 'active' : ''}`}
                onClick={() => setSettingsTab(key)}
              >
                {label}
              </button>
            ))}
          </div>

          {settingsTab === 'perfil' && (
            <>
              <div className="field-group">
                <label>Nome do assistente</label>
                <input
                  key={config.assistantName}
                  type="text"
                  defaultValue={config.assistantName}
                  placeholder="Higgs"
                  onBlur={(e) => updateConfig({ assistantName: e.target.value.trim() || 'Higgs' })}
                  onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                />
              </div>

              <div className="field-group">
                <label>Personalidade</label>
                <select value={config.personality} onChange={(e) => updateConfig({ personality: e.target.value })}>
                  {Object.entries(PERSONALITY_LABELS).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>

              <div className="field-group">
                <label>Cor de destaque</label>
                <div className="swatch-row">
                  {Object.entries(ACCENT_PRESETS).map(([key, preset]) => (
                    <button
                      key={key}
                      className={`swatch ${config.accentColor === key ? 'active' : ''}`}
                      style={{ background: preset.hex }}
                      title={preset.label}
                      onClick={() => updateConfig({ accentColor: key })}
                    />
                  ))}
                </div>
              </div>
            </>
          )}

          {settingsTab === 'ia' && (
            <>
              <div className="field-group">
                <label>Provedor de IA</label>
                <select value={config.provider} onChange={(e) => { updateConfig({ provider: e.target.value }); setTestResult(null); }}>
                  <option value="groq">Groq (nuvem)</option>
                  <option value="mistral">Mistral (nuvem)</option>
                  <option value="deepseek">DeepSeek (nuvem)</option>
                </select>
              </div>

              {config.provider === 'mistral' && (
                <>
                  <div className="field-group">
                    <label>Chave de API Mistral</label>
                    <input
                      key={`mistral-key-${config.mistralApiKey}`}
                      type="password"
                      defaultValue={config.mistralApiKey}
                      onBlur={(e) => updateConfig({ mistralApiKey: e.target.value.trim() })}
                      onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                      placeholder="Cole sua chave aqui"
                    />
                  </div>
                  <div className="field-group">
                    <label>Modelo</label>
                    <input
                      key={`mistral-model-${config.mistralModel}`}
                      type="text"
                      defaultValue={config.mistralModel}
                      onBlur={(e) => updateConfig({ mistralModel: e.target.value.trim() || 'mistral-small-latest' })}
                      onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                    />
                  </div>
                </>
              )}

              {config.provider === 'groq' && (
                <>
                  <div className="field-group">
                    <label>Chave de API Groq</label>
                    <input
                      key={`groq-key-${config.groqApiKey}`}
                      type="password"
                      defaultValue={config.groqApiKey}
                      onBlur={(e) => updateConfig({ groqApiKey: e.target.value.trim() })}
                      onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                      placeholder="Cole sua chave aqui"
                    />
                  </div>
                  <div className="field-group">
                    <label>Modelo</label>
                    <input
                      key={`groq-model-${config.groqModel}`}
                      type="text"
                      defaultValue={config.groqModel}
                      onBlur={(e) => updateConfig({ groqModel: e.target.value.trim() || 'openai/gpt-oss-20b' })}
                      onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                    />
                  </div>
                  <p className="hint-text">
                    Se a Groq trocar o nome do modelo de novo (já aconteceu com o `llama-3.1-8b-instant`), veja o
                    nome atual em console.groq.com/docs/models e cole aqui.
                  </p>
                </>
              )}

              {config.provider === 'deepseek' && (
                <>
                  <div className="field-group">
                    <label>Chave de API DeepSeek</label>
                    <input
                      key={`deepseek-key-${config.deepseekApiKey}`}
                      type="password"
                      defaultValue={config.deepseekApiKey}
                      onBlur={(e) => updateConfig({ deepseekApiKey: e.target.value.trim() })}
                      onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                      placeholder="Cole sua chave aqui"
                    />
                  </div>
                  <div className="field-group">
                    <label>Modelo</label>
                    <select value={config.deepseekModel} onChange={(e) => updateConfig({ deepseekModel: e.target.value })}>
                      <option value="deepseek-v4-flash">Flash (rápido, uso geral)</option>
                      <option value="deepseek-v4-pro">Pro (raciocínio avançado, contexto maior)</option>
                    </select>
                  </div>
                  <p className="hint-text">O DeepSeek ainda não processa imagens — não funciona com o recurso de print.</p>
                </>
              )}

              <button className="ghost-btn-full" onClick={testConnection} disabled={testingConnection}>
                {testingConnection ? 'Testando…' : 'Testar conexão'}
              </button>
              {testResult && (
                <p className={`hint-text ${testResult.ok ? 'test-ok' : 'test-fail'}`}>
                  {testResult.ok ? '✓ ' : '✗ '}{testResult.message}
                </p>
              )}

              {config.provider === 'mistral' && (
                <button className="ghost-btn-full" onClick={openMistralSignup}>
                  <ExternalLink size={14} /> Criar chave do Mistral
                </button>
              )}
              {config.provider === 'groq' && (
                <button className="ghost-btn-full" onClick={openGroqSignup}>
                  <ExternalLink size={14} /> Criar chave gratuita do Groq
                </button>
              )}
              {config.provider === 'deepseek' && (
                <button className="ghost-btn-full" onClick={openDeepseekSignup}>
                  <ExternalLink size={14} /> Criar chave do DeepSeek
                </button>
              )}
            </>
          )}

          {settingsTab === 'voz' && (
            <>
              <div className="field-group">
                <label>Voz do comando</label>
                <select value={config.voiceLanguage} onChange={(e) => updateConfig({ voiceLanguage: e.target.value })}>
                  <option value="pt">Português</option>
                  <option value="en">Inglês (estilo formal/britânico)</option>
                </select>
              </div>

              <div className="field-group">
                <label>Voz</label>
                <select value={config.ttsVoice} onChange={(e) => updateConfig({ ttsVoice: e.target.value })}>
                  {voices.map((v) => <option key={v.id} value={v.id}>{v.label}</option>)}
                </select>
              </div>

              <div className="field-group">
                <label>Velocidade da voz</label>
                <select value={config.ttsRate} onChange={(e) => updateConfig({ ttsRate: e.target.value })}>
                  <option value="-15%">Mais lenta</option>
                  <option value="+0%">Normal</option>
                  <option value="+15%">Mais rápida</option>
                </select>
              </div>

              <div className="field-group">
                <label>Tom da voz</label>
                <select value={config.ttsPitch} onChange={(e) => updateConfig({ ttsPitch: e.target.value })}>
                  <option value="-15%">Mais grave</option>
                  <option value="-8%">Grave (padrão)</option>
                  <option value="+0%">Normal</option>
                  <option value="+10%">Mais aguda</option>
                </select>
              </div>

              <div className="field-group">
                <label>Volume da voz</label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={config.ttsVolume}
                  onChange={(e) => updateConfig({ ttsVolume: parseFloat(e.target.value) })}
                  className="volume-slider"
                />
                <span className="volume-value">{Math.round(config.ttsVolume * 100)}%</span>
              </div>

              <div className="field-group">
                <label>Voz mutada</label>
                <input
                  type="checkbox"
                  className="field-checkbox"
                  checked={config.voiceMuted}
                  onChange={(e) => {
                    updateConfig({ voiceMuted: e.target.checked });
                    if (e.target.checked) stopSpeaking();
                  }}
                />
              </div>

              <button className="ghost-btn-full" onClick={testVoice}>
                <Volume2 size={14} /> Testar voz
              </button>

              <p className="hint-text">
                Segure o 🎤 (ou a barra de espaço fora do campo de texto) para gravar um comando de voz, e solte para
                transcrever e enviar. Isso usa a chave do Groq configurada na aba IA.
              </p>
            </>
          )}

          {settingsTab === 'memoria' && (
            <>
              <p className="hint-text">
                Fatos que o {config.assistantName || 'Higgs'} vai lembrar em <strong>toda</strong> conversa nova —
                quem você é, seus projetos, preferências. Ele também guarda sozinho, sem comando, quando percebe algo
                memorável na conversa. Pra adicionar manualmente, digite <strong>/lembrar seu texto</strong> no chat
                ou use o campo abaixo.
              </p>
              <div className="memory-add-row">
                <input
                  type="text"
                  value={newMemoryText}
                  onChange={(e) => setNewMemoryText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newMemoryText.trim()) {
                      addMemory(newMemoryText);
                      setNewMemoryText('');
                    }
                  }}
                  placeholder="Ex: trabalho como designer freelancer"
                />
                <button
                  className="ghost-btn"
                  onClick={() => {
                    if (newMemoryText.trim()) {
                      addMemory(newMemoryText);
                      setNewMemoryText('');
                    }
                  }}
                >
                  <Plus size={14} />
                </button>
              </div>
              <div className="panel-list">
                {(config.memories || []).length === 0 ? (
                  <div className="empty-state">Nada guardado ainda</div>
                ) : (
                  (config.memories || []).map((m) => (
                    <div key={m.id} className="list-item">
                      <div className="list-item-info">
                        <div className="list-item-title">{m.text}</div>
                      </div>
                      <button className="ghost-btn" onClick={() => removeMemory(m.id)}>
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </>
          )}

          {settingsTab === 'sistema' && (
            <>
              <div className="field-group">
                <label>Sempre no topo</label>
                <input
                  type="checkbox"
                  className="field-checkbox"
                  checked={config.alwaysOnTop}
                  onChange={(e) => {
                    updateConfig({ alwaysOnTop: e.target.checked });
                    window.electron.window.setAlwaysOnTop(e.target.checked);
                  }}
                />
              </div>

              <div className="field-group">
                <label>Iniciar com o Windows</label>
                <input
                  type="checkbox"
                  className="field-checkbox"
                  checked={autostartEnabled}
                  onChange={(e) => {
                    setAutostartEnabled(e.target.checked);
                    window.electron.autostart.set(e.target.checked);
                  }}
                />
              </div>

              <div className="field-group">
                <label>Não perturbe</label>
                <input
                  type="checkbox"
                  className="field-checkbox"
                  checked={config.doNotDisturb}
                  onChange={(e) => updateConfig({ doNotDisturb: e.target.checked })}
                />
              </div>
              <p className="hint-text">Pausa as notificações do Windows (respostas prontas, lembretes) sem desligar mais nada.</p>

              <div className="field-group">
                <label>Cidade (clima)</label>
                <input
                  key={config.city}
                  type="text"
                  defaultValue={config.city}
                  placeholder="Ex: São Paulo"
                  onBlur={(e) => updateConfig({ city: e.target.value.trim() })}
                  onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
                />
              </div>

              <div className="field-divider" />

              <div className="field-group">
                <label>Acesso pelo celular</label>
                <input
                  type="checkbox"
                  className="field-checkbox"
                  checked={!!mobileInfo?.enabled}
                  onChange={toggleMobileAccess}
                />
              </div>

              {mobileInfo?.enabled && (
                <div className="mobile-access-box">
                  <p className="hint-text">
                    No celular, na <strong>mesma rede Wi-Fi</strong>, abra no navegador:
                  </p>
                  <div className="mobile-access-row">
                    <code>{mobileInfo.url}</code>
                  </div>
                  <div className="mobile-access-row">
                    <span>PIN:</span> <code className="mobile-pin">{mobileInfo.pin}</code>
                    <button className="ghost-btn" onClick={regenerateMobilePin} title="Gerar novo PIN">
                      ↻
                    </button>
                  </div>
                </div>
              )}

              <div className="field-divider" />

              <div className="field-group">
                <label>Backup completo</label>
                <button className="ghost-btn-full" onClick={exportFullBackup}>
                  <Download size={14} /> Exportar tudo
                </button>
              </div>
              <div className="field-group">
                <label></label>
                <button className="ghost-btn-full" onClick={() => backupInputRef.current?.click()}>
                  <Upload size={14} /> Importar backup
                </button>
                <input
                  ref={backupInputRef}
                  type="file"
                  accept="application/json"
                  style={{ display: 'none' }}
                  onChange={(e) => importFullBackup(e.target.files?.[0])}
                />
              </div>
              <p className="hint-text">
                O backup inclui configurações, personalidade, memória permanente e conversas salvas — tudo num único
                arquivo. Guarde-o em algum lugar seguro (nuvem, pendrive) para nunca perder nada, mesmo formatando o PC.
              </p>

              <div className="field-divider" />

              <div className="field-group">
                <label>Atalho: mostrar/ocultar</label>
                <input
                  key={`toggle-${config.shortcutToggle}`}
                  ref={shortcutToggleInputRef}
                  type="text"
                  defaultValue={config.shortcutToggle}
                  placeholder="CommandOrControl+Shift+J"
                />
              </div>
              <div className="field-group">
                <label>Atalho: print + pergunta</label>
                <input
                  key={`screenshot-${config.shortcutScreenshot}`}
                  ref={shortcutScreenshotInputRef}
                  type="text"
                  defaultValue={config.shortcutScreenshot}
                  placeholder="CommandOrControl+Shift+H"
                />
              </div>
              <button
                className="ghost-btn-full"
                onClick={() => {
                  const toggle = shortcutToggleInputRef.current?.value.trim() || 'CommandOrControl+Shift+J';
                  const screenshotKey = shortcutScreenshotInputRef.current?.value.trim() || 'CommandOrControl+Shift+H';
                  saveShortcuts(toggle, screenshotKey);
                }}
              >
                {shortcutSaved ? '✓ Salvo' : 'Salvar atalhos'}
              </button>
              <p className="hint-text">
                Use o formato do Electron, ex: <strong>CommandOrControl+Shift+K</strong>. "CommandOrControl" vira Ctrl
                no Windows. Se o atalho já estiver em uso por outro programa, o Higgs avisa e mantém o anterior.
              </p>

              <div className="field-divider" />

              <p className="hint-text">
                Comandos rápidos (funcionam mesmo sem IA): <strong>/hora</strong> · <strong>/data</strong> ·{' '}
                <strong>/clima</strong> · <strong>/sistema</strong> · <strong>/lembrete 10 texto</strong> ·{' '}
                <strong>/lembrar fato</strong> · <strong>/memoria</strong> · <strong>/esquecer nº</strong> ·{' '}
                <strong>/limpar</strong> · <strong>/ajuda</strong>
                <br />
                Atalho global <strong>{config.shortcutToggle}</strong> chama o {config.assistantName || 'Higgs'} de qualquer
                lugar. <strong>{config.shortcutScreenshot}</strong> tira um print e já deixa pronto pra você perguntar sobre o que
                está na tela (ou clique no ícone 📷 ao lado do microfone). Fechar a janela minimiza para a bandeja do
                sistema — ele continua ativo.
              </p>

              <div className="field-divider" />

              <div className="field-group">
                <label>Versão</label>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: 'var(--text-mid)' }}>
                  {appVersion || '—'}
                </span>
              </div>

              {updateState.status === 'idle' && (
                <button className="ghost-btn-full" onClick={checkForUpdate}>
                  Verificar atualizações
                </button>
              )}
              {updateState.status === 'checking' && (
                <button className="ghost-btn-full" disabled>Verificando…</button>
              )}
              {updateState.status === 'available' && (
                <button className="ghost-btn-full" onClick={downloadUpdate}>
                  Nova versão {updateState.version} disponível — Baixar
                </button>
              )}
              {updateState.status === 'downloading' && (
                <button className="ghost-btn-full" disabled>Baixando… {updateState.percent}%</button>
              )}
              {updateState.status === 'ready' && (
                <button className="ghost-btn-full" onClick={installUpdate}>
                  ✓ Atualização pronta — Reiniciar e instalar
                </button>
              )}
              {updateState.status === 'error' && (
                <>
                  <button className="ghost-btn-full" onClick={checkForUpdate}>Tentar de novo</button>
                  <p className="hint-text test-fail">{updateState.error}</p>
                </>
              )}
              <p className="hint-text">
                Atualizações são baixadas do GitHub Releases do projeto. Isso só funciona depois de configurar o
                repositório e publicar uma release — veja o README.
              </p>
            </>
          )}
        </div>
      )}

      <div className="messages-container">
        {messages.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role === 'user' ? 'user-message' : 'ai-message'}`}>
            {msg.image && <img src={msg.image} alt="Print anexado" className="message-image" />}
            {msg.fileName && (
              <div className="message-file-chip">
                <FileText size={12} /> {msg.fileName}
              </div>
            )}
            <div
              className="message-content"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
            />
            <div className="message-meta">
              <span>{formatClock(msg.timestamp)}</span>
              {msg.role !== 'user' && msg.role !== 'system' && (
                <button className="copy-btn" onClick={() => copyMessage(msg.content, idx)} title="Copiar">
                  {copiedIdx === idx ? <Check size={12} /> : <Copy size={12} />}
                </button>
              )}
            </div>
          </div>
        ))}
        {isProcessing && (
          <div className="message ai-message processing">
            <div className="message-content">
              {streamingText ? (
                <span dangerouslySetInnerHTML={{ __html: renderMarkdown(streamingText) }} />
              ) : (
                <div className="loading-dots"><span /><span /><span /></div>
              )}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="input-area">
        {!providerReady() && (
          <div className="status-warning">
            Configure a chave de API do {PROVIDER_LABELS[config.provider]} em Configurações.
          </div>
        )}
        {errorBanner && <div className="status-warning">{errorBanner}</div>}
        {attachedScreenshot && (
          <div className="screenshot-preview">
            <img src={attachedScreenshot.dataUrl} alt="Imagem anexada" />
            <span className="screenshot-preview-label">
              {attachedScreenshot.fileName ? `${attachedScreenshot.fileName} — o que você quer saber?` : 'O que você quer saber sobre isso?'}
            </span>
            {attachedScreenshot.displayCount > 1 && (
              <button className="ghost-btn" onClick={switchCapturedDisplay} title="Trocar de tela">
                Tela {attachedScreenshot.displayIndex + 1}/{attachedScreenshot.displayCount} ↻
              </button>
            )}
            <button className="ghost-btn" onClick={() => setAttachedScreenshot(null)} title="Remover">
              <X size={13} />
            </button>
          </div>
        )}
        {attachedTextFile && (
          <div className="screenshot-preview">
            <FileText size={20} className="dash-weather-icon" />
            <span className="screenshot-preview-label">{attachedTextFile.name} anexado — pergunte algo sobre ele</span>
            <button className="ghost-btn" onClick={() => setAttachedTextFile(null)} title="Remover">
              <X size={13} />
            </button>
          </div>
        )}
        <div className="input-controls">
          <button
            className="icon-btn round"
            onClick={attachFile}
            disabled={isProcessing}
            title="Anexar imagem ou arquivo de texto"
          >
            <Paperclip size={18} />
          </button>
          <button
            className="icon-btn round"
            onClick={takeScreenshot}
            disabled={isProcessing || !providerReady()}
            title={`Tirar print e perguntar (${config.shortcutScreenshot})`}
          >
            <Camera size={18} />
          </button>
          <button
            className={`icon-btn round ${isListening ? 'active' : ''}`}
            onMouseDown={beginRecording}
            onMouseUp={endRecording}
            onMouseLeave={endRecording}
            onTouchStart={beginRecording}
            onTouchEnd={endRecording}
            disabled={isProcessing || isTranscribing || !providerReady()}
            title="Segure para gravar, solte para enviar"
          >
            <Mic size={18} />
          </button>
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                processMessage(input);
              }
            }}
            placeholder={attachedScreenshot ? 'O que você quer saber sobre a imagem?' : 'Comando ou pergunta... (Shift+Enter para quebrar linha)'}
            className="input-field"
            rows={1}
            disabled={!providerReady()}
          />
          <button
            className="icon-btn round primary"
            onClick={() => processMessage(input)}
            disabled={isProcessing || !input.trim() || !providerReady()}
            title="Enviar (Enter)"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
