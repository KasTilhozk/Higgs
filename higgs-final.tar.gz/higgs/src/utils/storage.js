const STORAGE_KEY = 'jarvis_conversations';
const MAX_CONVERSATIONS = 50;

export const storage = {
  // Salvar conversa
  saveConversation: (messages, title = null) => {
    try {
      const conversations = storage.getConversations();
      const timestamp = new Date().toISOString();
      const firstUserMsg = messages.find((m) => m.role === 'user')?.content || '';
      const snippet = firstUserMsg.length > 40 ? `${firstUserMsg.slice(0, 40)}…` : firstUserMsg;
      const conversationTitle = title || snippet || `Conversa ${new Date().toLocaleDateString('pt-BR')}`;
      
      const conversation = {
        id: `conv_${Date.now()}`,
        title: conversationTitle,
        messages,
        timestamp,
        messageCount: messages.length,
      };

      conversations.unshift(conversation);
      
      // Manter apenas as últimas MAX_CONVERSATIONS
      if (conversations.length > MAX_CONVERSATIONS) {
        conversations.pop();
      }

      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
      return conversation;
    } catch (error) {
      console.error('Erro ao salvar conversa:', error);
      return null;
    }
  },

  // Obter todas as conversas
  getConversations: () => {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Erro ao obter conversas:', error);
      return [];
    }
  },

  // Atualizar uma conversa existente (usado para ir acumulando mensagens
  // da MESMA sessão em vez de criar um registro novo a cada troca)
  updateConversation: (id, messages) => {
    try {
      const conversations = storage.getConversations();
      const idx = conversations.findIndex((c) => c.id === id);
      if (idx === -1) return null;
      conversations[idx] = {
        ...conversations[idx],
        messages,
        messageCount: messages.length,
        timestamp: new Date().toISOString(),
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
      return conversations[idx];
    } catch (error) {
      console.error('Erro ao atualizar conversa:', error);
      return null;
    }
  },

  // Obter conversa específica
  getConversation: (id) => {
    try {
      const conversations = storage.getConversations();
      return conversations.find(conv => conv.id === id);
    } catch (error) {
      console.error('Erro ao obter conversa:', error);
      return null;
    }
  },

  // Deletar conversa
  deleteConversation: (id) => {
    try {
      const conversations = storage.getConversations();
      const filtered = conversations.filter(conv => conv.id !== id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
      return true;
    } catch (error) {
      console.error('Erro ao deletar conversa:', error);
      return false;
    }
  },

  // Limpar todas as conversas
  clearAll: () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      return true;
    } catch (error) {
      console.error('Erro ao limpar conversas:', error);
      return false;
    }
  },

  // Exportar conversas como JSON
  exportConversations: () => {
    try {
      const conversations = storage.getConversations();
      const dataStr = JSON.stringify(conversations, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `higgs-conversas-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erro ao exportar conversas:', error);
    }
  },
};
