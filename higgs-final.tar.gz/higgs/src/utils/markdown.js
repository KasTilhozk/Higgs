function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderInline(text) {
  return text
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, '<em>$1</em>')
    // [texto](url) — só http(s), pra não virar javascript:/data: escondido
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

// Converte um subconjunto de Markdown (negrito, itálico, código inline,
// blocos de código, links, listas) em HTML seguro. O texto é escapado antes
// de qualquer substituição, então nada de HTML vindo do modelo é executado —
// só as tags que nós mesmos inserimos aqui.
export function renderMarkdown(rawText) {
  const escaped = escapeHtml(rawText || '');
  const lines = escaped.split('\n');
  const htmlParts = [];
  let listBuffer = [];
  let listType = null;
  let inCodeBlock = false;
  let codeBuffer = [];

  const flushList = () => {
    if (listBuffer.length) {
      const tag = listType === 'ol' ? 'ol' : 'ul';
      htmlParts.push(`<${tag}>${listBuffer.join('')}</${tag}>`);
      listBuffer = [];
      listType = null;
    }
  };

  for (const line of lines) {
    // Bloco de código: ```linguagem opcional ... ```
    if (line.trim().startsWith('```')) {
      if (inCodeBlock) {
        htmlParts.push(`<pre><code>${codeBuffer.join('\n')}</code></pre>`);
        codeBuffer = [];
        inCodeBlock = false;
      } else {
        flushList();
        inCodeBlock = true;
      }
      continue;
    }
    if (inCodeBlock) {
      codeBuffer.push(line);
      continue;
    }

    const bulletMatch = line.match(/^\s*[-*]\s+(.*)/);
    const numberedMatch = line.match(/^\s*\d+\.\s+(.*)/);

    if (bulletMatch) {
      listType = 'ul';
      listBuffer.push(`<li>${renderInline(bulletMatch[1])}</li>`);
    } else if (numberedMatch) {
      listType = 'ol';
      listBuffer.push(`<li>${renderInline(numberedMatch[1])}</li>`);
    } else {
      flushList();
      if (line.trim() === '') {
        htmlParts.push('<br/>');
      } else {
        htmlParts.push(`<p>${renderInline(line)}</p>`);
      }
    }
  }
  flushList();
  // Bloco de código sem fechamento (resposta cortada no meio) — mostra o
  // que tem em vez de sumir com o conteúdo
  if (inCodeBlock && codeBuffer.length) {
    htmlParts.push(`<pre><code>${codeBuffer.join('\n')}</code></pre>`);
  }

  return htmlParts.join('');
}
