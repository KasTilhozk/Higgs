# Higgs - Personal AI Assistant Desktop Application

Aplicação desktop de assistente pessoal, construída com Electron + React.
Nome padrão "Higgs" (editável a qualquer momento), com voz neural, memória
permanente e três provedores de IA em nuvem: **Groq**, **Mistral** e
**DeepSeek** — você usa sua própria chave de API, sem precisar de nada
instalado localmente.

## Características

- **Identidade visual própria**: fundo grafite, um núcleo flutuante que é um visualizador de áudio de verdade — as barras ao redor dele reagem em tempo real ao volume e à frequência da própria voz do Higgs enquanto ele fala, e ao seu microfone enquanto você grava (igual aos visualizadores de música), com tipografia Space Grotesk + Inter + JetBrains Mono
- **Janela própria, sem menu genérico**: sem a barra de título padrão do Windows nem o menu "File/Edit/View" — janela sem moldura com controles próprios (minimizar/maximizar/fechar) e sequência de inicialização ao abrir
- **Voz neural**: usa as vozes neurais gratuitas da Microsoft Edge (Read Aloud) — muito mais naturais que a voz robótica padrão do Windows, sem precisar de chave de API. Cai automaticamente para a voz do sistema se a internet cair.
- **Multi-provedor em nuvem**: alterne entre Groq / Mistral / DeepSeek nas Configurações, com botão de "Testar conexão" pra confirmar que a chave e o modelo ainda funcionam, e failover automático se um provedor cair
- **Reconhecimento de Voz**: reconhecimento de fala em português (via microfone, transcrito pelo Groq Whisper)
- **Histórico Persistente**: conversas salvas localmente, com carregar/exportar/apagar
- **Configuração Segura**: chaves de API ficam só no seu computador, num arquivo
  local fora do repositório — nunca em texto fixo no código

## Requisitos

- Node.js 18+
- npm
- Uma chave de API de pelo menos um provedor (Groq tem plano gratuito generoso)

## Instalação

```bash
cd higgs
npm install
npm run dev
```

## Configurando um motor de IA

1. Abra o app → ⚙️ Configurações → aba "IA" → escolha o provedor (Groq, Mistral ou DeepSeek)
2. Cole sua própria chave de API (crie uma em console.groq.com, console.mistral.ai
   ou platform.deepseek.com/api_keys — tem um botão direto pra cada uma)
3. Clique em "Testar conexão" pra confirmar que funcionou
4. A chave fica salva apenas no seu computador (pasta de dados do usuário do
   Electron), nunca é enviada a lugar nenhum além da API escolhida

**Recomendação:** Groq tem o plano gratuito mais generoso e é o mais rápido —
bom ponto de partida. Configure uma segunda chave (Mistral ou DeepSeek) como
reserva — se o Groq cair ou atingir limite de uso, o Higgs troca sozinho.

DeepSeek tem dois modelos: **Flash** (rápido, uso geral) e **Pro** (raciocínio
mais profundo, contexto maior) — mas ainda não processa imagens, então não
funciona com o recurso de print (use Groq ou Mistral pra isso).

> ⚠️ **Nunca** compartilhe suas chaves de API em chats, capturas de tela ou
> repositórios públicos. Se uma chave já foi exposta, revogue-a e gere outra.
>
> Nomes de modelo em provedores de nuvem mudam com frequência (isso já
> aconteceu com o Groq e o DeepSeek). Se um dia o "Testar conexão" começar a
> falhar, o modelo provavelmente foi descontinuado e o nome precisa ser
> atualizado no código.

## Comando de voz (microfone)

O reconhecimento de fala do navegador não funciona dentro do Electron (falta o
backend proprietário do Google que o Chrome tem). Por isso, o comando de voz
usa a transcrição do **Groq Whisper** — tem plano gratuito, é só criar uma
conta em console.groq.com (tem um botão direto em Configurações) e colar a
chave, mesmo que você use Mistral ou DeepSeek pra conversar.

**Como usar:** segure o botão 🎤 (ou a barra de espaço, com o campo de texto
sem foco) para gravar, e solte para transcrever e enviar automaticamente —
sem precisar clicar duas vezes.

## Configurando a voz

Em ⚙️ Configurações, escolha entre 4 vozes neurais em português (Antônio,
Francisca, Thalita, Donato) ou vozes em inglês formal/britânico (Ryan,
Thomas, Guy, Andrew). Clique em "Testar voz" para ouvir antes de conversar.
Sem internet, o app usa a voz padrão do Windows automaticamente.

## Personalidade e identidade

Em ⚙️ Configurações:
- **Nome do assistente** — o padrão é "Higgs", mas chame-o do que preferir; o nome aparece no cabeçalho, na saudação, nas notificações e é usado nas respostas da IA
- **Personalidade** — Sarcástico, Formal, Direto, Amigável, ou **Amigo pra amigo** (casual, zero formalidade, trata como parceiro mesmo)
- **Tom da voz** — de mais grave a mais aguda, sem distorcer o áudio (usa o controle de pitch nativo da voz neural, não é um efeito artificial)
- **Volume da voz** — slider de 0 a 100%, afeta tanto a voz neural quanto a voz de fallback do Windows
- **Mutar voz** — botão de acesso rápido no cabeçalho (🔇) ou checkbox em Configurações; corta qualquer fala em andamento na hora. Comandos, lembretes e respostas continuam funcionando normalmente, só sem áudio.
- **Cor de destaque** — 4 opções (Teal, Roxo, Azul, Rosa), aplicada em todo o app incluindo o núcleo visual
- **Sempre no topo** — mantém a janela por cima de tudo
- **Iniciar com o Windows** — abre sozinho (minimizado na bandeja) quando o PC liga
- **Não perturbe** — pausa as notificações do Windows

Ao abrir o app, ele te dá boas-vindas em voz, com saudação de acordo com o
horário (bom dia / boa tarde / boa noite) — e some o "senhor" quando a
personalidade é "Amigo pra amigo".

## Memória permanente

Diferente do histórico de conversas (que precisa ser carregado manualmente),
a memória permanente é injetada **automaticamente em toda conversa nova** —
o assistente nunca esquece quem você é, mesmo começando do zero. Ele também
guarda fatos sozinho, sem comando, quando percebe algo memorável na conversa.

- `/lembrar <fato>` no chat — ex: `/lembrar meu nome é Kauan e trabalho com design`
- `/memoria` — lista tudo que está guardado
- `/esquecer <número>` — remove um item específico da lista
- Também dá pra gerenciar visualmente em ⚙️ Configurações → aba "Memória" (adicionar, listar, apagar)

Funciona com qualquer provedor (Groq, Mistral, DeepSeek) e também no acesso
pelo celular — a memória é compartilhada entre PC e celular.

## Comandos rápidos

Digite no campo de texto (funcionam mesmo com o provedor de IA indisponível):

| Comando | O que faz |
|---|---|
| `/hora` | Diz a hora atual |
| `/data` | Diz a data de hoje |
| `/clima` | Consulta o clima da cidade configurada |
| `/sistema` | Mostra uso de CPU e RAM |
| `/lembrete 10 beber água` | Programa um lembrete falado + notificação em N minutos |
| `/lembrar meu nome é...` | Guarda um fato permanente (lembrado em toda conversa futura) |
| `/memoria` | Lista os fatos guardados |
| `/esquecer 2` | Remove o fato de número 2 da lista |
| `/limpar` | Começa uma nova conversa |
| `/ajuda` | Lista os comandos |

Lembretes continuam funcionando mesmo se você minimizar a janela para a
bandeja — o Higgs segue ativo em segundo plano (mas são perdidos se você
"Sair" de verdade pelo menu da bandeja).

## Recursos de conversa

- Texto com múltiplas linhas (Shift+Enter quebra linha, Enter envia)
- Respostas com formatação (negrito, listas, blocos de código, links)
- Respostas em tempo real (efeito de "digitando"), nos três provedores
- Botão de copiar em cada resposta do Higgs, e um botão no cabeçalho para copiar a conversa inteira
- Atalhos: `Ctrl+N` nova conversa · `Ctrl+,` configurações · `Esc` fecha painéis

## Painel (relógio, clima, sistema)

Logo abaixo do cabeçalho, um painel mostra:
- **Relógio e data** com saudação de acordo com a hora do dia
- **Clima** da cidade que você configurar em ⚙️ (usa Open-Meteo, gratuito e
  sem chave de API)
- **CPU e RAM** reais do seu computador, atualizados a cada poucos segundos

## Tirar dúvidas sobre o que está na tela

Aperte o atalho configurado (padrão **Ctrl+Shift+H**, editável em ⚙️
Configurações → Sistema) de qualquer lugar do Windows, ou clique no ícone 📷
ao lado do microfone — ele tira um print da tela **onde está o seu cursor**
(funciona certo com múltiplos monitores), mostra o app, anexa uma prévia da
imagem acima do campo de texto e já deixa o cursor pronto. Se capturou a tela
errada, tem um botão pra trocar entre os monitores sem precisar tirar o print
de novo. Digite sua pergunta e mande — a resposta aparece no chat normal, com
a miniatura da imagem junto da sua pergunta.

**Isso precisa de um modelo com visão** (nem todo modelo entende imagem):
- **Groq**: usa `qwen/qwen3.6-27b` automaticamente, sem configurar nada
- **Mistral**: usa `pixtral-12b-2409` automaticamente
- **DeepSeek**: ainda não suporta imagens — troque de provedor pra usar esse recurso

Os nomes dos modelos de nuvem foram checados em agosto de 2026; provedores
trocam esses nomes com frequência, então se um dia parar de funcionar,
provavelmente o modelo foi descontinuado e precisa atualizar o nome no código.

## Anexar arquivo (imagem ou texto)

Clique no ícone 📎 pra anexar um arquivo do seu computador — imagem
(png/jpg/gif/webp, mesmo fluxo de visão do print) ou texto (txt/md/csv/json,
até 300 KB). Pra arquivo de texto, o conteúdo vira contexto pra sua pergunta
sem poluir a conversa — só aparece o nome do arquivo na bolha da mensagem.

## Se um provedor cair, tenta outro sozinho

Se o provedor selecionado falhar no meio de uma resposta (chave inválida,
fora do ar, limite de uso), o Higgs tenta automaticamente o próximo provedor
que já tenha uma chave configurada, avisando qual troca fez. Só mostra erro
de verdade se todos falharem — por isso vale configurar mais de um provedor.

## Acesso pelo celular

Em ⚙️ Configurações, ative "Acesso pelo celular". O app mostra um endereço
(ex: `http://192.168.1.23:4477`) e um PIN de 4 dígitos.

No celular, **na mesma rede Wi-Fi de casa**, abra esse endereço no navegador,
digite o PIN uma vez (ele fica salvo), e pronto — chat com a mesma
personalidade, nome e provedor de IA configurados no PC. Não precisa
instalar nada no celular.

**Limitações honestas:**
- Só funciona na mesma rede Wi-Fi — fora de casa (4G, outra rede) não
  conecta. Para acesso de qualquer lugar, seria necessário configurar algo
  como Tailscale (rede privada gratuita) — não incluído aqui, mas é o próximo
  passo natural se você quiser isso depois.
- O PC precisa estar aberto (pode estar minimizado na bandeja) para o celular
  conseguir se conectar.
- O PIN é uma proteção simples, não é uma senha forte — qualquer um na mesma
  rede Wi-Fi que souber o PIN consegue usar. Gere um novo PIN quando quiser
  (botão ↻ ao lado dele).

## Sempre disponível (bandeja + atalho global)

- Atalho global (padrão **`Ctrl+Shift+J`**, editável em ⚙️ Configurações →
  Sistema) chama o Higgs de qualquer lugar do sistema, mesmo com outro
  programa em foco. Se o atalho já estiver em uso por outro programa, o app
  avisa em vez de falhar em silêncio.
- Fechar a janela (X) minimiza para a **bandeja do sistema** em vez de
  encerrar — o Higgs continua rodando. Clique no ícone da bandeja pra
  reabrir, ou "Sair" no menu da bandeja pra encerrar de vez
- **Notificação do sistema** quando uma resposta fica pronta com a janela em
  segundo plano — desligável em ⚙️ Configurações → Sistema → "Não perturbe"

## Uso

1. `npm run dev` (desenvolvimento) ou `npm start` após `npm run build`
2. O indicador no header mostra se o provedor ativo está pronto
3. Digite ou use o microfone 🎤
4. **➕** inicia uma nova conversa · **💾** abre o histórico (clique num item
   para recarregar) · **⚙️** abre as configurações

## Instalador de verdade (sem precisar de CMD/npm depois)

Isso empacota o Higgs como um programa Windows normal — instalador com
assistente, atalho na Área de Trabalho e no Menu Iniciar, aparece em
"Aplicativos instalados" pra desinstalar. Depois de instalado, dá duplo
clique e abre, sem precisar de terminal nunca mais.

```bash
cd higgs
npm install
npm run build
```

Isso gera o instalador em `release/`:
- **`Higgs-Setup-1.0.0.exe`** — roda o assistente de instalação, escolhe a
  pasta, cria os atalhos.

O build demora alguns minutos na primeira vez (baixa o Electron e as
dependências nativas). Ao final, é só levar o `Higgs-Setup-1.0.0.exe` pra
qualquer pasta e instalar como qualquer outro programa.

> Isso só funciona rodando no Windows (não dá pra gerar o `.exe` a partir de
> Linux/Mac sem ferramentas extras). Se você usa Windows, é só rodar os
> comandos acima normalmente.

## Distribuir pra outras pessoas + atualização automática (via GitHub)

Isso deixa o Higgs "de verdade": link fixo pra baixar, e o app se atualiza
sozinho quando você publicar uma versão nova — sem custo nenhum (a única
coisa que continua exigindo dinheiro é remover o aviso do Windows
Defender/SmartScreen, que precisa de um certificado pago; isso aqui não
resolve isso, só o resto).

### 1. Criar o repositório no GitHub

1. Crie uma conta grátis em **github.com** (se ainda não tiver)
2. Clique em "New repository" → nome: `higgs` → marque **Public** → criar
3. Suba o código do projeto pra esse repositório (pode usar o GitHub Desktop,
   que tem interface gráfica, se não quiser usar comandos de `git`)

### 2. Apontar o app pro seu usuário

No `package.json`, ache a seção `"publish"` e troque `SEU-USUARIO-GITHUB`
pelo seu nome de usuário real do GitHub:

```json
"publish": {
  "provider": "github",
  "owner": "seu-usuario-aqui",
  "repo": "higgs"
}
```

### 3. Criar um token de acesso (só uma vez)

1. No GitHub: foto de perfil → Settings → Developer settings → Personal
   access tokens → Tokens (classic) → Generate new token
2. Marque a permissão **`repo`** → gere o token → **copie ele** (só aparece
   uma vez)

### 4. Publicar uma versão

No CMD, dentro da pasta do projeto:

```bash
set GH_TOKEN=cole_seu_token_aqui
npm run build -- --publish always
```

Isso builda o instalador **e** já publica automaticamente uma Release no
GitHub, com todos os arquivos que o sistema de atualização precisa.

### 5. Compartilhar o link de download

A página `https://github.com/seu-usuario/higgs/releases` tem sempre a versão
mais recente — é esse link que você manda pra família/amigos. Lá tem um botão
de download direto do `Higgs-Setup-x.x.x.exe`, sem precisar de conta no
GitHub nem saber nada de programação.

### 6. Lançar uma atualização depois

1. Mude a versão no `package.json` (ex: `"version": "1.0.0"` → `"1.0.1"`)
2. Rode o mesmo comando do passo 4 de novo
3. Quem já tem o Higgs instalado recebe um aviso dentro do próprio app
   (⚙️ Configurações → Sistema → "Nova versão disponível") — clica em
   "Baixar" e depois "Reiniciar e instalar", pronto

## Estrutura do Projeto

```
higgs/
├── main.js                  # Processo principal Electron (IPC, provedores de IA, config)
├── preload.js                # Ponte segura entre main e renderer
├── assets/                   # Ícones do app
├── src/
│   ├── App.jsx                 # Componente principal
│   ├── components/HUD.jsx      # Barra de status
│   ├── components/Dashboard.jsx # Relógio, clima, CPU/RAM
│   ├── components/ReactorCore.jsx # Núcleo visual (visualizador de áudio)
│   ├── hooks/useVoice.js       # Reconhecimento e síntese de voz
│   └── utils/storage.js        # Histórico de conversas (localStorage)
└── package.json
```

## Troubleshooting

**"Configure a chave de API..."** — provedor de nuvem selecionado sem chave
salva; abra Configurações → aba "IA" e cole a chave, depois clique em
"Testar conexão".

**Comando de voz não funciona** — precisa de uma chave do Groq configurada
(mesmo que você use outro provedor pra conversar) — veja a seção "Comando de
voz" acima.

**Atalho de teclado não funciona** — pode estar em conflito com outro
programa; o app avisa quando isso acontece. Troque o atalho em ⚙️
Configurações → Sistema.

## Licença

MIT
