const { app, BrowserWindow, ipcMain, session, shell, Menu, Tray, Notification, globalShortcut, nativeImage, screen, desktopCapturer, dialog } = require('electron');
const { autoUpdater } = require('electron-updater');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const { MsEdgeTTS, OUTPUT_FORMAT } = require('msedge-tts');

const isDev = !app.isPackaged;

let mainWindow;
let tray = null;
let mobileServer = null;
const MOBILE_PORT = 4477;

// ---------------------------------------------------------------------------
// Configuração persistente (arquivo local em userData, NUNCA no localStorage
// do renderer e NUNCA versionado no git). Guarda apenas o que o usuário digita
// nas Configurações — nenhuma chave vem pré-preenchida com o app.
// ---------------------------------------------------------------------------
const CONFIG_PATH = path.join(app.getPath('userData'), 'higgs-config.json');
const LEGACY_CONFIG_PATH = path.join(app.getPath('userData'), 'jarvis-config.json');

const DEFAULT_CONFIG = {
  provider: 'groq',
  mistralApiKey: '',
  mistralModel: 'mistral-small-latest',
  groqApiKey: '',
  groqModel: 'openai/gpt-oss-20b',
  deepseekApiKey: '',
  deepseekModel: 'deepseek-v4-flash',
  ttsVoice: 'pt-BR-AntonioNeural',
  ttsRate: '+0%',
  ttsPitch: '-8%',
  ttsVolume: 1,
  voiceLanguage: 'pt',
  city: '',
  assistantName: 'Higgs',
  personality: 'sarcastic',
  accentColor: 'teal',
  alwaysOnTop: false,
  voiceMuted: false,
  memories: [],
  autoMemory: true,
  mobileAccessEnabled: false,
  mobilePin: '',
  shortcutToggle: 'CommandOrControl+Shift+J',
  shortcutScreenshot: 'CommandOrControl+Shift+H',
  doNotDisturb: false,
};

function loadConfig() {
  try {
    if (!fs.existsSync(CONFIG_PATH) && fs.existsSync(LEGACY_CONFIG_PATH)) {
      // Migração de quem já usava o app com o nome de arquivo antigo —
      // preserva configurações e memória em vez de resetar tudo.
      fs.copyFileSync(LEGACY_CONFIG_PATH, CONFIG_PATH);
    }
    if (fs.existsSync(CONFIG_PATH)) {
      const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
      const merged = { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
      if (merged.provider === 'ollama') merged.provider = 'groq';
      if (merged.groqModel === 'llama-3.1-8b-instant') merged.groqModel = 'openai/gpt-oss-20b';
      if (merged.groqModel === 'llama-3.3-70b-versatile') merged.groqModel = 'openai/gpt-oss-120b';
      return merged;
    }
  } catch (err) {
    console.error('Erro ao ler config:', err);
  }
  return { ...DEFAULT_CONFIG };
}

function saveConfig(config) {
  const merged = { ...loadConfig(), ...config };
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(merged, null, 2), 'utf-8');
  return merged;
}

function createWindow() {
  Menu.setApplicationMenu(null);

  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 860,
    minHeight: 600,
    frame: false,
    title: loadConfig().assistantName || 'Higgs',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
    icon: path.join(__dirname, 'assets/icon.png'),
    backgroundColor: '#0a0b0e',
    alwaysOnTop: loadConfig().alwaysOnTop || false,
  });

  const startUrl = isDev
    ? 'http://localhost:5173'
    : `file://${path.join(__dirname, 'dist/index.html')}`;

  mainWindow.loadURL(startUrl);

  // DevTools não abre mais sozinho — aperte F12 se precisar dele algum dia
  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F12') {
      mainWindow.webContents.toggleDevTools();
    }
  });

  mainWindow.on('maximize', () => mainWindow.webContents.send('window:state', 'maximized'));
  mainWindow.on('unmaximize', () => mainWindow.webContents.send('window:state', 'normal'));

  // Fechar minimiza para a bandeja em vez de encerrar — o JARVIS continua
  // rodando e escutando o atalho global, como um assistente sempre ativo.
  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

async function getScreenSources() {
  const displays = screen.getAllDisplays();
  const maxWidth = Math.max(...displays.map((d) => d.size.width * (d.scaleFactor || 1)));
  const maxHeight = Math.max(...displays.map((d) => d.size.height * (d.scaleFactor || 1)));
  const sources = await desktopCapturer.getSources({
    types: ['screen'],
    thumbnailSize: { width: Math.round(maxWidth), height: Math.round(maxHeight) },
  });
  return { sources, displays };
}

async function captureAndAsk() {
  if (!mainWindow) return;

  const wasVisible = mainWindow.isVisible();
  if (wasVisible) {
    mainWindow.hide();
    await new Promise((resolve) => setTimeout(resolve, 200));
  }

  try {
    // Captura a tela onde o cursor está no momento — em setups com mais de
    // um monitor, é quase sempre a que a pessoa quer perguntar sobre.
    const cursorPoint = screen.getCursorScreenPoint();
    const activeDisplay = screen.getDisplayNearestPoint(cursorPoint);
    const { sources, displays } = await getScreenSources();

    const activeIndex = displays.findIndex((d) => d.id === activeDisplay.id);
    const source = sources[activeIndex] || sources[0];
    if (!source) throw new Error('Nenhuma tela encontrada para capturar.');

    const dataUrl = source.thumbnail.toDataURL();
    mainWindow.show();
    mainWindow.focus();
    mainWindow.webContents.send('screenshot:captured', {
      dataUrl,
      displayIndex: Math.max(0, activeIndex),
      displayCount: displays.length,
    });
  } catch (error) {
    mainWindow.show();
    mainWindow.webContents.send('screenshot:error', error.message);
  }
}

// Recaptura uma tela específica (usado pelo botão "trocar tela" na prévia,
// quando a pessoa tem mais de um monitor e a captura pegou o errado).
async function captureSpecificDisplay(displayIndex) {
  const { sources, displays } = await getScreenSources();
  const source = sources[displayIndex];
  if (!source) throw new Error('Essa tela não está mais disponível.');
  return {
    dataUrl: source.thumbnail.toDataURL(),
    displayIndex,
    displayCount: displays.length,
  };
}

// ---------------------------------------------------------------------------
// Atualização automática (via GitHub Releases) — nunca baixa nem instala
// sozinho sem a pessoa confirmar, e nunca trava o app se falhar (sem
// internet, sem repositório configurado ainda, etc).
// ---------------------------------------------------------------------------
autoUpdater.autoDownload = false;
autoUpdater.autoInstallOnAppQuit = true;

autoUpdater.on('update-available', (info) => {
  mainWindow?.webContents.send('update:available', info.version);
});

autoUpdater.on('update-not-available', () => {
  mainWindow?.webContents.send('update:notAvailable');
});

autoUpdater.on('download-progress', (progress) => {
  mainWindow?.webContents.send('update:progress', Math.round(progress.percent));
});

autoUpdater.on('update-downloaded', () => {
  mainWindow?.webContents.send('update:ready');
});

autoUpdater.on('error', (error) => {
  mainWindow?.webContents.send('update:error', error.message);
});

function checkForUpdates(manual) {
  autoUpdater.checkForUpdates().catch((error) => {
    // Silencioso quando é checagem automática de fundo (sem internet, sem
    // release publicado ainda) — só avisa quando a pessoa pediu manualmente.
    if (manual) mainWindow?.webContents.send('update:error', error.message);
  });
}

function createTray() {
  const trayIcon = nativeImage.createFromPath(path.join(__dirname, 'assets/tray-icon.png'));
  tray = new Tray(trayIcon);
  tray.setToolTip(loadConfig().assistantName || 'Higgs');
  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: `Abrir ${loadConfig().assistantName || 'Higgs'}`,
        click: () => {
          mainWindow.show();
          mainWindow.focus();
        },
      },
      {
        label: 'Sair',
        click: () => {
          app.isQuitting = true;
          app.quit();
        },
      },
    ])
  );
  tray.on('click', () => {
    if (mainWindow.isVisible()) {
      mainWindow.hide();
    } else {
      mainWindow.show();
      mainWindow.focus();
    }
  });
}

app.on('ready', () => {
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    callback(permission === 'media');
  });
  createWindow();
  createTray();

  if (loadConfig().mobileAccessEnabled) {
    startMobileServer();
  }

  registerShortcuts();

  if (app.isPackaged) {
    setTimeout(() => checkForUpdates(false), 4000);
  }
});

// Registra os dois atalhos globais a partir da configuração (permite
// trocar depois pelas Configurações). Se um atalho já estiver em uso por
// outro programa, o registro falha silenciosamente por padrão no Electron —
// aqui a gente avisa a pessoa em vez de deixar passar batido.
function registerShortcuts() {
  globalShortcut.unregisterAll();
  const cfg = loadConfig();
  const failed = [];

  const safeRegister = (accelerator, fallback, handler) => {
    try {
      const ok = globalShortcut.register(accelerator, handler);
      if (!ok) throw new Error('registro recusado');
      return true;
    } catch (e) {
      try {
        globalShortcut.register(fallback, handler);
      } catch (e2) {
        // mesmo o padrão falhou (raríssimo) — segue sem esse atalho
      }
      return false;
    }
  };

  const toggleAccel = cfg.shortcutToggle || 'CommandOrControl+Shift+J';
  const toggleOk = safeRegister(toggleAccel, 'CommandOrControl+Shift+J', () => {
    if (!mainWindow) return;
    if (mainWindow.isVisible() && mainWindow.isFocused()) {
      mainWindow.hide();
    } else {
      mainWindow.show();
      mainWindow.focus();
    }
  });
  if (!toggleOk) failed.push(toggleAccel);

  const screenshotAccel = cfg.shortcutScreenshot || 'CommandOrControl+Shift+H';
  const screenshotOk = safeRegister(screenshotAccel, 'CommandOrControl+Shift+H', () => {
    captureAndAsk();
  });
  if (!screenshotOk) failed.push(screenshotAccel);

  if (failed.length && mainWindow) {
    const msg = `Não consegui ativar o atalho ${failed.join(' e ')} — outro programa já está usando essa combinação.`;
    const send = () => mainWindow.webContents.send('shortcuts:conflict', msg);
    if (mainWindow.webContents.isLoading()) {
      mainWindow.webContents.once('did-finish-load', send);
    } else {
      send();
    }
  }
}

app.on('before-quit', () => {
  app.isQuitting = true;
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  stopMobileServer();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// ---------------------------------------------------------------------------
// Configuração (IPC)
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Controles de janela (a barra de título nativa foi removida)
// ---------------------------------------------------------------------------
ipcMain.handle('notify:show', (event, { title, body }) => {
  if (Notification.isSupported() && !loadConfig().doNotDisturb) {
    new Notification({ title: title || 'Higgs', body: body || '' }).show();
  }
});

ipcMain.on('window:minimize', () => mainWindow?.minimize());
ipcMain.on('window:maximize', () => {
  if (!mainWindow) return;
  mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
});
ipcMain.on('window:close', () => mainWindow?.close());
ipcMain.handle('window:isMaximized', () => mainWindow?.isMaximized() || false);
ipcMain.on('window:setAlwaysOnTop', (event, value) => mainWindow?.setAlwaysOnTop(value));

ipcMain.handle('shortcuts:update', (event, { shortcutToggle, shortcutScreenshot }) => {
  saveConfig({ shortcutToggle, shortcutScreenshot });
  registerShortcuts();
  return { shortcutToggle, shortcutScreenshot };
});

ipcMain.handle('autostart:get', () => app.getLoginItemSettings().openAtLogin);

ipcMain.handle('update:check', () => {
  if (!app.isPackaged) {
    return { error: 'Verificação de atualização só funciona no app instalado, não em modo de desenvolvimento.' };
  }
  checkForUpdates(true);
  return { checking: true };
});

ipcMain.handle('update:download', () => {
  autoUpdater.downloadUpdate().catch((error) => {
    mainWindow?.webContents.send('update:error', error.message);
  });
});

ipcMain.on('update:install', () => {
  app.isQuitting = true;
  autoUpdater.quitAndInstall();
});

ipcMain.handle('app:version', () => app.getVersion());
ipcMain.on('autostart:set', (event, enabled) => {
  app.setLoginItemSettings({ openAtLogin: enabled, openAsHidden: true });
});

ipcMain.handle('config:get', () => loadConfig());
ipcMain.handle('config:set', (event, partialConfig) => {
  const updated = saveConfig(partialConfig);
  if (partialConfig.assistantName && mainWindow) {
    mainWindow.setTitle(partialConfig.assistantName);
  }
  return updated;
});

// Memória: sempre lê o arquivo mais recente do disco antes de adicionar/
// remover, em vez de confiar na cópia que o renderer tinha em memória —
// evita que duas gravações quase simultâneas (ex: uma manual e uma
// automática) se sobrescrevam.
ipcMain.handle('memory:add', (event, text) => {
  const clean = (text || '').trim();
  if (!clean) return loadConfig();
  const current = loadConfig();
  const entry = { id: Date.now(), text: clean, timestamp: Date.now() };
  return saveConfig({ memories: [...(current.memories || []), entry] });
});

ipcMain.handle('memory:remove', (event, id) => {
  const current = loadConfig();
  return saveConfig({ memories: (current.memories || []).filter((m) => m.id !== id) });
});

// ---------------------------------------------------------------------------
// Utilitário de fetch com timeout (usado pelos provedores em nuvem)
// ---------------------------------------------------------------------------
async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

// ---------------------------------------------------------------------------
// Mistral (IA em nuvem, opcional)
// ---------------------------------------------------------------------------
async function chatMistral(apiKey, model, messages) {
  if (!apiKey) throw new Error('Chave de API do Mistral não configurada.');
  const response = await fetchWithTimeout(
    'https://api.mistral.ai/v1/chat/completions',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ model, messages, max_tokens: 800 }),
    },
    30000
  );
  const data = await response.json();
  if (!response.ok || !data.choices) {
    throw new Error(`Mistral: ${data.message || data.error?.message || response.statusText}`);
  }
  return data.choices[0].message.content;
}

// ---------------------------------------------------------------------------
// Groq (IA em nuvem, opcional)
// ---------------------------------------------------------------------------
async function chatGroq(apiKey, model, messages) {
  if (!apiKey) throw new Error('Chave de API do Groq não configurada.');
  const response = await fetchWithTimeout(
    'https://api.groq.com/openai/v1/chat/completions',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ model, messages, max_tokens: 800 }),
    },
    30000
  );
  const data = await response.json();
  if (!response.ok || !data.choices) {
    throw new Error(`Groq: ${data.error?.message || response.statusText}`);
  }
  return data.choices[0].message.content;
}

async function chatDeepseek(apiKey, model, messages) {
  if (!apiKey) throw new Error('Chave de API do DeepSeek não configurada.');
  const response = await fetchWithTimeout(
    'https://api.deepseek.com/chat/completions',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ model, messages, max_tokens: 800 }),
    },
    60000
  );
  const data = await response.json();
  if (!response.ok || !data.choices) {
    throw new Error(`DeepSeek: ${data.error?.message || response.statusText}`);
  }
  return data.choices[0].message.content;
}

// ---------------------------------------------------------------------------
// Streaming — mesmas chamadas acima, só que lendo a resposta aos poucos e
// entregando cada pedacinho pro renderer (efeito de "digitando").
// ---------------------------------------------------------------------------
async function streamOpenAICompatible(url, apiKey, model, messages, onDelta, providerLabel) {
  if (!apiKey) throw new Error(`Chave de API do ${providerLabel} não configurada.`);
  const response = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages, max_tokens: 800, stream: true }),
  });
  if (!response.ok || !response.body) {
    let errMsg = response.statusText;
    try {
      const data = await response.json();
      errMsg = data.error?.message || data.message || errMsg;
    } catch (e) {
      // corpo não era JSON (raro), mantém statusText
    }
    throw new Error(`${providerLabel}: ${errMsg}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let full = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const payload = trimmed.slice(5).trim();
      if (payload === '[DONE]') continue;
      try {
        const json = JSON.parse(payload);
        const delta = json.choices?.[0]?.delta?.content;
        if (delta) {
          full += delta;
          onDelta(delta);
        }
      } catch (e) {
        // fragmento parcial de uma linha maior, ignora e segue
      }
    }
  }
  return full;
}

ipcMain.on('ai:chatStream', async (event, { requestId, provider, model, messages, apiKey }) => {
  const sender = event.sender;
  const onDelta = (delta) => sender.send('ai:chatStreamChunk', { requestId, delta });

  try {
    let full;
    if (provider === 'mistral') {
      full = await streamOpenAICompatible('https://api.mistral.ai/v1/chat/completions', apiKey, model, messages, onDelta, 'Mistral');
    } else if (provider === 'groq') {
      full = await streamOpenAICompatible('https://api.groq.com/openai/v1/chat/completions', apiKey, model, messages, onDelta, 'Groq');
    } else if (provider === 'deepseek') {
      full = await streamOpenAICompatible('https://api.deepseek.com/chat/completions', apiKey, model, messages, onDelta, 'DeepSeek');
    } else {
      throw new Error(`Provedor desconhecido: ${provider}`);
    }

    if (mainWindow && !mainWindow.isFocused() && Notification.isSupported()) {
      const cfg = loadConfig();
      if (!cfg.doNotDisturb) {
        new Notification({ title: cfg.assistantName || 'Higgs', body: full.slice(0, 150) }).show();
      }
    }
    sender.send('ai:chatStreamDone', { requestId, content: full });
  } catch (error) {
    sender.send('ai:chatStreamError', { requestId, message: error.message });
  }
});

// ---------------------------------------------------------------------------
// Voz neural (Microsoft Edge Read Aloud — vozes naturais, sem chave de API)
// ---------------------------------------------------------------------------
ipcMain.handle('tts:speak', async (event, { text, voice, rate, pitch }) => {
  const tts = new MsEdgeTTS();
  await tts.setMetadata(
    voice || 'pt-BR-AntonioNeural',
    OUTPUT_FORMAT.AUDIO_24KHZ_96KBITRATE_MONO_MP3
  );
  const { audioStream } = tts.toStream(text, { rate: rate || '+0%', pitch: pitch || '-8%' });

  const chunks = [];
  await new Promise((resolve, reject) => {
    audioStream.on('data', (chunk) => chunks.push(chunk));
    audioStream.on('end', resolve);
    audioStream.on('close', resolve);
    audioStream.on('error', reject);
  });

  const audioBuffer = Buffer.concat(chunks);
  if (audioBuffer.length === 0) {
    throw new Error('Sem áudio recebido do serviço de voz.');
  }
  return { audioBase64: audioBuffer.toString('base64') };
});

// Vozes neurais do Edge Read Aloud. As "en-GB" são vozes formais/britânicas
// genéricas da Microsoft — a opção mais próxima, sem clonar a voz de nenhum
// ator ou personagem específico.
ipcMain.handle('tts:voices', (event, language) => {
  if (language === 'en') {
    return [
      { id: 'en-GB-RyanNeural', label: 'Ryan (britânico, formal)' },
      { id: 'en-GB-ThomasNeural', label: 'Thomas (britânico, grave)' },
      { id: 'en-US-GuyNeural', label: 'Guy (americano)' },
      { id: 'en-US-AndrewNeural', label: 'Andrew (americano, calmo)' },
    ];
  }
  return [
    { id: 'pt-BR-AntonioNeural', label: 'Antônio (masculina)' },
    { id: 'pt-BR-FranciscaNeural', label: 'Francisca (feminina)' },
    { id: 'pt-BR-ThalitaNeural', label: 'Thalita (feminina)' },
    { id: 'pt-BR-DonatoNeural', label: 'Donato (masculina)' },
  ];
});

// Abrir links externos (ex: criar conta grátis no Groq) no navegador padrão
ipcMain.handle('shell:openExternal', (event, url) => {
  if (typeof url === 'string' && url.startsWith('https://')) {
    shell.openExternal(url);
  }
});

// ---------------------------------------------------------------------------
// Reconhecimento de voz (Groq Whisper — o Web Speech API do navegador não
// funciona dentro do Electron porque falta o backend proprietário do Google)
// ---------------------------------------------------------------------------
ipcMain.handle('stt:transcribe', async (event, { audioBase64, apiKey }) => {
  if (!apiKey) {
    throw new Error('Configure a chave do Groq (gratuita) nas Configurações para usar comando de voz.');
  }
  const audioBuffer = Buffer.from(audioBase64, 'base64');
  const form = new FormData();
  form.append('file', new Blob([audioBuffer], { type: 'audio/webm' }), 'audio.webm');
  form.append('model', 'whisper-large-v3-turbo');
  form.append('language', 'pt');

  const response = await fetchWithTimeout(
    'https://api.groq.com/openai/v1/audio/transcriptions',
    { method: 'POST', headers: { Authorization: `Bearer ${apiKey}` }, body: form },
    30000
  );
  const data = await response.json();
  if (!response.ok) {
    throw new Error(`Groq (voz): ${data.error?.message || response.statusText}`);
  }
  return { text: (data.text || '').trim() };
});

ipcMain.handle('ai:chat', async (event, { provider, model, messages, apiKey }) => {
  try {
    let content;
    if (provider === 'mistral') {
      content = await chatMistral(apiKey, model, messages);
    } else if (provider === 'groq') {
      content = await chatGroq(apiKey, model, messages);
    } else if (provider === 'deepseek') {
      content = await chatDeepseek(apiKey, model, messages);
    } else {
      throw new Error(`Provedor desconhecido: ${provider}`);
    }
    if (mainWindow && !mainWindow.isFocused() && Notification.isSupported()) {
      const cfg = loadConfig();
      if (!cfg.doNotDisturb) {
        new Notification({ title: cfg.assistantName || 'Higgs', body: content.slice(0, 150) }).show();
      }
    }
    return { message: { content } };
  } catch (error) {
    const reason = error.name === 'AbortError' ? 'Timeout: sem resposta a tempo' : error.message;
    throw new Error(reason);
  }
});

// ---------------------------------------------------------------------------
// Captura de tela + pergunta ("o que tem nessa tela?") — atalho global
// Ctrl+Shift+H ou botão de câmera no app.
// ---------------------------------------------------------------------------
ipcMain.handle('screenshot:trigger', () => captureAndAsk());
ipcMain.handle('screenshot:captureDisplay', (event, displayIndex) => captureSpecificDisplay(displayIndex));

const IMAGE_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp'];
const TEXT_EXTENSIONS = ['.txt', '.md', '.csv', '.json', '.log'];
const MIME_BY_EXT = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.bmp': 'image/bmp' };

ipcMain.handle('file:attach', async () => {
  if (!mainWindow) return null;
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Imagens e texto', extensions: [...IMAGE_EXTENSIONS, ...TEXT_EXTENSIONS].map((e) => e.slice(1)) },
    ],
  });
  if (result.canceled || !result.filePaths.length) return null;

  const filePath = result.filePaths[0];
  const ext = path.extname(filePath).toLowerCase();
  const name = path.basename(filePath);

  if (IMAGE_EXTENSIONS.includes(ext)) {
    const buffer = fs.readFileSync(filePath);
    const mime = MIME_BY_EXT[ext] || 'image/png';
    return { kind: 'image', name, dataUrl: `data:${mime};base64,${buffer.toString('base64')}` };
  }
  if (TEXT_EXTENSIONS.includes(ext)) {
    const stat = fs.statSync(filePath);
    if (stat.size > 300 * 1024) {
      throw new Error('Arquivo de texto muito grande (limite de 300 KB).');
    }
    const content = fs.readFileSync(filePath, 'utf-8');
    return { kind: 'text', name, content };
  }
  throw new Error('Tipo de arquivo não suportado. Use imagem (png/jpg/gif/webp) ou texto (txt/md/csv/json/log).');
});

// Modelos de visão atuais de cada provedor (checados em agosto de 2026 —
// esses nomes mudam com frequência nos provedores em nuvem).
const VISION_MODELS = {
  groq: 'qwen/qwen3.6-27b',
  mistral: 'pixtral-12b-2409',
};

async function chatVisionMistral(apiKey, question, imageDataUrl) {
  if (!apiKey) throw new Error('Chave de API do Mistral não configurada.');
  const response = await fetchWithTimeout(
    'https://api.mistral.ai/v1/chat/completions',
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: VISION_MODELS.mistral,
        messages: [
          { role: 'user', content: [{ type: 'text', text: question }, { type: 'image_url', image_url: imageDataUrl }] },
        ],
        max_tokens: 800,
      }),
    },
    30000
  );
  const data = await response.json();
  if (!response.ok || !data.choices) {
    throw new Error(`Mistral: ${data.message || data.error?.message || response.statusText}`);
  }
  return data.choices[0].message.content;
}

async function chatVisionGroq(apiKey, question, imageDataUrl) {
  if (!apiKey) throw new Error('Chave de API do Groq não configurada.');
  const response = await fetchWithTimeout(
    'https://api.groq.com/openai/v1/chat/completions',
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: VISION_MODELS.groq,
        messages: [
          { role: 'user', content: [{ type: 'text', text: question }, { type: 'image_url', image_url: { url: imageDataUrl } }] },
        ],
        max_tokens: 800,
      }),
    },
    30000
  );
  const data = await response.json();
  if (!response.ok || !data.choices) {
    throw new Error(`Groq: ${data.error?.message || response.statusText}`);
  }
  return data.choices[0].message.content;
}

ipcMain.handle('ai:chatVision', async (event, { provider, model, question, imageDataUrl, apiKey }) => {
  try {
    let content;
    if (provider === 'mistral') {
      content = await chatVisionMistral(apiKey, question, imageDataUrl);
    } else if (provider === 'groq') {
      content = await chatVisionGroq(apiKey, question, imageDataUrl);
    } else {
      throw new Error(`O provedor "${provider}" não processa imagens.`);
    }
    return { message: { content } };
  } catch (error) {
    const reason = error.name === 'AbortError' ? 'Timeout: sem resposta a tempo' : error.message;
    throw new Error(reason);
  }
});

// ---------------------------------------------------------------------------
// Acesso pelo celular (rede local) — o PC vira um servidor que o celular
// acessa pelo navegador, na mesma rede Wi-Fi. Sem instalar nada no celular.
// ---------------------------------------------------------------------------
const MOBILE_PERSONALITIES = {
  sarcastic: 'Seja breve, elegante e sarcástico.',
  formal: 'Seja extremamente formal, cortês e profissional, como um mordomo britânico.',
  direct: 'Seja direto, objetivo e conciso, sem rodeios.',
  friendly: 'Seja caloroso, amigável e encorajador.',
  buddy: 'Fale de igual para igual, como um amigo próximo de longa data: casual, caloroso, bem-humorado, sem nenhuma formalidade — nunca chame de "senhor".',
};

function getLocalIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  return '127.0.0.1';
}

function generatePin() {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

function renderMobilePage(cfg) {
  const name = cfg.assistantName || 'Higgs';
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>${name}</title>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; background: #0a0b0e; color: #eaedf2; font-family: -apple-system, Inter, sans-serif; height: 100vh; display: flex; flex-direction: column; }
  header { padding: 16px 18px; border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; gap: 10px; }
  header .dot { width: 8px; height: 8px; border-radius: 50%; background: #4fd8c4; box-shadow: 0 0 8px rgba(79,216,196,0.7); }
  header h1 { font-size: 16px; margin: 0; letter-spacing: 0.05em; }
  #pin-screen { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 14px; padding: 24px; }
  #pin-screen input { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); color: #eaedf2; padding: 12px 16px; border-radius: 10px; font-size: 20px; text-align: center; width: 160px; letter-spacing: 0.1em; }
  #pin-screen button, #chat-screen button { background: rgba(79,216,196,0.16); color: #4fd8c4; border: 1px solid rgba(79,216,196,0.3); padding: 10px 18px; border-radius: 10px; font-size: 14px; }
  #chat-screen { flex: 1; display: none; flex-direction: column; overflow: hidden; }
  #messages { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 10px; }
  .msg { max-width: 78%; padding: 10px 14px; border-radius: 12px; font-size: 14.5px; line-height: 1.4; }
  .user { align-self: flex-end; background: rgba(79,216,196,0.12); border: 1px solid rgba(79,216,196,0.22); }
  .ai { align-self: flex-start; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); }
  #input-row { display: flex; gap: 8px; padding: 12px; border-top: 1px solid rgba(255,255,255,0.08); }
  #input-row input { flex: 1; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); color: #eaedf2; padding: 12px 14px; border-radius: 20px; font-size: 14px; }
  #error { color: #ff6b6b; font-size: 12px; text-align: center; min-height: 16px; }
</style>
</head>
<body>
  <header><span class="dot"></span><h1>${name.toUpperCase()}</h1></header>

  <div id="pin-screen">
    <p>Digite o PIN mostrado no app do PC:</p>
    <input id="pin-input" inputmode="numeric" maxlength="4" placeholder="0000" />
    <button onclick="tryPin()">Entrar</button>
    <div id="error"></div>
  </div>

  <div id="chat-screen">
    <div id="messages"></div>
    <div id="input-row">
      <input id="text-input" placeholder="Comando ou pergunta..." />
      <button onclick="send()">➤</button>
    </div>
  </div>

<script>
  const history = [];
  function tryPin() {
    const pin = document.getElementById('pin-input').value.trim();
    localStorage.setItem('jarvis_pin', pin);
    document.getElementById('pin-screen').style.display = 'none';
    document.getElementById('chat-screen').style.display = 'flex';
    addMsg('ai', '${name} online. Pode falar.');
  }
  if (localStorage.getItem('jarvis_pin')) {
    document.getElementById('pin-screen').style.display = 'none';
    document.getElementById('chat-screen').style.display = 'flex';
    addMsg('ai', '${name} online. Pode falar.');
  }
  function addMsg(role, text) {
    const div = document.createElement('div');
    div.className = 'msg ' + (role === 'user' ? 'user' : 'ai');
    div.textContent = text;
    document.getElementById('messages').appendChild(div);
    div.scrollIntoView();
  }
  async function send() {
    const input = document.getElementById('text-input');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    addMsg('user', text);
    history.push({ role: 'user', content: text });
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-jarvis-pin': localStorage.getItem('jarvis_pin') || '' },
        body: JSON.stringify({ history }),
      });
      const data = await res.json();
      if (data.error) {
        document.getElementById('error').textContent = data.error;
        if (res.status === 401) {
          localStorage.removeItem('jarvis_pin');
          document.getElementById('chat-screen').style.display = 'none';
          document.getElementById('pin-screen').style.display = 'flex';
        }
        return;
      }
      addMsg('ai', data.content);
      history.push({ role: 'assistant', content: data.content });
    } catch (e) {
      addMsg('ai', 'Erro de conexão: ' + e.message);
    }
  }
  document.getElementById('text-input')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });
</script>
</body>
</html>`;
}

function startMobileServer() {
  if (mobileServer) return;
  mobileServer = http.createServer((req, res) => {
    const cfg = loadConfig();

    if (req.method === 'GET' && req.url === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(renderMobilePage(cfg));
      return;
    }

    if (req.method === 'POST' && req.url === '/api/chat') {
      let body = '';
      req.on('data', (chunk) => (body += chunk));
      req.on('end', async () => {
        try {
          if (!cfg.mobileAccessEnabled || req.headers['x-jarvis-pin'] !== cfg.mobilePin) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'PIN incorreto.' }));
            return;
          }
          const { history } = JSON.parse(body || '{}');
          const personalityLine = MOBILE_PERSONALITIES[cfg.personality] || MOBILE_PERSONALITIES.sarcastic;
          const memoryLine = (cfg.memories && cfg.memories.length)
            ? ` Fatos importantes sobre o usuário que você deve sempre lembrar: ${cfg.memories.map((m) => m.text).join('; ')}.`
            : '';
          const systemMsg = {
            role: 'system',
            content: `Você é o ${cfg.assistantName || 'Higgs'}, um assistente de IA. ${personalityLine} Responda em português.${memoryLine}`,
          };
          const messages = [systemMsg, ...(history || [])];

          let content;
          if (cfg.provider === 'mistral') content = await chatMistral(cfg.mistralApiKey, cfg.mistralModel, messages);
          else if (cfg.provider === 'groq') content = await chatGroq(cfg.groqApiKey, cfg.groqModel, messages);
          else if (cfg.provider === 'deepseek') content = await chatDeepseek(cfg.deepseekApiKey, cfg.deepseekModel, messages);
          else throw new Error(`Provedor desconhecido: ${cfg.provider}`);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ content }));
        } catch (error) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: error.message }));
        }
      });
      return;
    }

    res.writeHead(404);
    res.end();
  });
  mobileServer.listen(MOBILE_PORT, '0.0.0.0');
}

function stopMobileServer() {
  mobileServer?.close();
  mobileServer = null;
}

ipcMain.handle('mobile:getInfo', () => {
  const cfg = loadConfig();
  return { enabled: cfg.mobileAccessEnabled, url: `http://${getLocalIp()}:${MOBILE_PORT}`, pin: cfg.mobilePin };
});

ipcMain.handle('mobile:setEnabled', (event, enabled) => {
  const cfg = loadConfig();
  const pin = cfg.mobilePin || generatePin();
  const updated = saveConfig({ mobileAccessEnabled: enabled, mobilePin: pin });
  if (enabled) startMobileServer();
  else stopMobileServer();
  return { enabled: updated.mobileAccessEnabled, url: `http://${getLocalIp()}:${MOBILE_PORT}`, pin: updated.mobilePin };
});

ipcMain.handle('mobile:regeneratePin', () => {
  const updated = saveConfig({ mobilePin: generatePin() });
  return { pin: updated.mobilePin };
});

// ---------------------------------------------------------------------------
// Clima (Open-Meteo — gratuito, sem chave de API)
// ---------------------------------------------------------------------------
const WEATHER_CODES = {
  0: 'céu limpo', 1: 'poucas nuvens', 2: 'parcialmente nublado', 3: 'nublado',
  45: 'neblina', 48: 'neblina com geada',
  51: 'garoa leve', 53: 'garoa', 55: 'garoa forte',
  61: 'chuva leve', 63: 'chuva', 65: 'chuva forte',
  71: 'neve leve', 73: 'neve', 75: 'neve forte',
  80: 'pancadas de chuva', 81: 'pancadas de chuva', 82: 'pancadas fortes',
  95: 'tempestade', 96: 'tempestade com granizo', 99: 'tempestade forte',
};

const geocodeCache = new Map(); // cidade (minúsculo) -> { latitude, longitude, name, admin1 }

ipcMain.handle('weather:get', async (event, city) => {
  if (!city) return null;
  try {
    const cacheKey = city.trim().toLowerCase();
    let geoData = geocodeCache.get(cacheKey);

    if (!geoData) {
      const geoRes = await fetchWithTimeout(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=pt`,
        {},
        8000
      );
      const geo = await geoRes.json();
      if (!geo.results || !geo.results.length) {
        return { error: 'Cidade não encontrada.' };
      }
      const { latitude, longitude, name, admin1 } = geo.results[0];
      geoData = { latitude, longitude, name, admin1 };
      geocodeCache.set(cacheKey, geoData);
    }

    const wRes = await fetchWithTimeout(
      `https://api.open-meteo.com/v1/forecast?latitude=${geoData.latitude}&longitude=${geoData.longitude}&current=temperature_2m,weather_code,relative_humidity_2m&timezone=auto`,
      {},
      8000
    );
    const w = await wRes.json();
    return {
      city: geoData.name,
      region: geoData.admin1 || '',
      temp: Math.round(w.current.temperature_2m),
      humidity: w.current.relative_humidity_2m,
      description: WEATHER_CODES[w.current.weather_code] || '—',
      weatherCode: w.current.weather_code,
    };
  } catch (error) {
    return { error: error.message };
  }
});

// ---------------------------------------------------------------------------
// Monitor do sistema (CPU/RAM reais da máquina — sem dependências externas)
// ---------------------------------------------------------------------------
function measureCpuPercent() {
  return new Promise((resolve) => {
    const start = os.cpus();
    setTimeout(() => {
      const end = os.cpus();
      let idleDiff = 0;
      let totalDiff = 0;
      for (let i = 0; i < start.length; i++) {
        const sTotal = Object.values(start[i].times).reduce((a, b) => a + b, 0);
        const eTotal = Object.values(end[i].times).reduce((a, b) => a + b, 0);
        idleDiff += end[i].times.idle - start[i].times.idle;
        totalDiff += eTotal - sTotal;
      }
      resolve(totalDiff > 0 ? Math.round(100 * (1 - idleDiff / totalDiff)) : 0);
    }, 200);
  });
}

ipcMain.handle('system:stats', async () => {
  const cpuPercent = await measureCpuPercent();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  return {
    cpuPercent,
    ramPercent: Math.round(((totalMem - freeMem) / totalMem) * 100),
    ramUsedGB: (totalMem - freeMem) / 1024 ** 3,
    ramTotalGB: totalMem / 1024 ** 3,
  };
});
