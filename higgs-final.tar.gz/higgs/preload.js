const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electron', {
  window: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    close: () => ipcRenderer.send('window:close'),
    isMaximized: () => ipcRenderer.invoke('window:isMaximized'),
    setAlwaysOnTop: (value) => ipcRenderer.send('window:setAlwaysOnTop', value),
    onStateChange: (callback) => {
      const listener = (event, state) => callback(state);
      ipcRenderer.on('window:state', listener);
      return () => ipcRenderer.removeListener('window:state', listener);
    },
  },
  config: {
    get: () => ipcRenderer.invoke('config:get'),
    set: (partialConfig) => ipcRenderer.invoke('config:set', partialConfig),
  },
  tts: {
    speak: (text, voice, rate, pitch) => ipcRenderer.invoke('tts:speak', { text, voice, rate, pitch }),
    voices: (language) => ipcRenderer.invoke('tts:voices', language),
  },
  stt: {
    transcribe: (audioBase64, apiKey) => ipcRenderer.invoke('stt:transcribe', { audioBase64, apiKey }),
  },
  notify: {
    show: (title, body) => ipcRenderer.invoke('notify:show', { title, body }),
  },
  mobile: {
    getInfo: () => ipcRenderer.invoke('mobile:getInfo'),
    setEnabled: (enabled) => ipcRenderer.invoke('mobile:setEnabled', enabled),
    regeneratePin: () => ipcRenderer.invoke('mobile:regeneratePin'),
  },
  autostart: {
    get: () => ipcRenderer.invoke('autostart:get'),
    set: (enabled) => ipcRenderer.send('autostart:set', enabled),
  },
  update: {
    check: () => ipcRenderer.invoke('update:check'),
    download: () => ipcRenderer.invoke('update:download'),
    install: () => ipcRenderer.send('update:install'),
    getVersion: () => ipcRenderer.invoke('app:version'),
    onAvailable: (callback) => {
      const listener = (event, version) => callback(version);
      ipcRenderer.on('update:available', listener);
      return () => ipcRenderer.removeListener('update:available', listener);
    },
    onNotAvailable: (callback) => {
      const listener = () => callback();
      ipcRenderer.on('update:notAvailable', listener);
      return () => ipcRenderer.removeListener('update:notAvailable', listener);
    },
    onProgress: (callback) => {
      const listener = (event, percent) => callback(percent);
      ipcRenderer.on('update:progress', listener);
      return () => ipcRenderer.removeListener('update:progress', listener);
    },
    onReady: (callback) => {
      const listener = () => callback();
      ipcRenderer.on('update:ready', listener);
      return () => ipcRenderer.removeListener('update:ready', listener);
    },
    onError: (callback) => {
      const listener = (event, message) => callback(message);
      ipcRenderer.on('update:error', listener);
      return () => ipcRenderer.removeListener('update:error', listener);
    },
  },
  shell: {
    openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),
  },
  weather: {
    get: (city) => ipcRenderer.invoke('weather:get', city),
  },
  system: {
    stats: () => ipcRenderer.invoke('system:stats'),
  },
  ai: {
    chat: (provider, model, messages, apiKey) =>
      ipcRenderer.invoke('ai:chat', { provider, model, messages, apiKey }),
    chatVision: (provider, model, question, imageDataUrl, apiKey) =>
      ipcRenderer.invoke('ai:chatVision', { provider, model, question, imageDataUrl, apiKey }),
    chatStream: (payload) => ipcRenderer.send('ai:chatStream', payload),
    onStreamChunk: (callback) => {
      const listener = (event, data) => callback(data);
      ipcRenderer.on('ai:chatStreamChunk', listener);
      return () => ipcRenderer.removeListener('ai:chatStreamChunk', listener);
    },
    onStreamDone: (callback) => {
      const listener = (event, data) => callback(data);
      ipcRenderer.on('ai:chatStreamDone', listener);
      return () => ipcRenderer.removeListener('ai:chatStreamDone', listener);
    },
    onStreamError: (callback) => {
      const listener = (event, data) => callback(data);
      ipcRenderer.on('ai:chatStreamError', listener);
      return () => ipcRenderer.removeListener('ai:chatStreamError', listener);
    },
  },
  screenshot: {
    trigger: () => ipcRenderer.invoke('screenshot:trigger'),
    captureDisplay: (displayIndex) => ipcRenderer.invoke('screenshot:captureDisplay', displayIndex),
    onCaptured: (callback) => {
      const listener = (event, data) => callback(data);
      ipcRenderer.on('screenshot:captured', listener);
      return () => ipcRenderer.removeListener('screenshot:captured', listener);
    },
    onError: (callback) => {
      const listener = (event, message) => callback(message);
      ipcRenderer.on('screenshot:error', listener);
      return () => ipcRenderer.removeListener('screenshot:error', listener);
    },
  },
  shortcuts: {
    update: (shortcutToggle, shortcutScreenshot) =>
      ipcRenderer.invoke('shortcuts:update', { shortcutToggle, shortcutScreenshot }),
    onConflict: (callback) => {
      const listener = (event, message) => callback(message);
      ipcRenderer.on('shortcuts:conflict', listener);
      return () => ipcRenderer.removeListener('shortcuts:conflict', listener);
    },
  },
  memory: {
    add: (text) => ipcRenderer.invoke('memory:add', text),
    remove: (id) => ipcRenderer.invoke('memory:remove', id),
  },
  file: {
    attach: () => ipcRenderer.invoke('file:attach'),
  },
});
