import React, { useRef, useEffect } from 'react';

function getColors(accentHex, accentRgb) {
  return {
    idle: { core: '#f2a65a', bar: '242,166,90', glow: 'rgba(242,166,90,0.35)' },
    listening: { core: '#ff6b6b', bar: '255,107,107', glow: 'rgba(255,107,107,0.4)' },
    thinking: { core: accentHex, bar: accentRgb, glow: `rgba(${accentRgb},0.35)` },
    speaking: { core: accentHex, bar: accentRgb, glow: `rgba(${accentRgb},0.45)` },
  };
}

const BAR_COUNT = 48;

export default function ReactorCore({ state = 'idle', analyserRef, size = 64, accentHex = '#4fd8c4', accentRgb = '79,216,196' }) {
  const canvasRef = useRef(null);
  const levelsRef = useRef(new Array(BAR_COUNT).fill(0));
  const rafRef = useRef(null);
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const dataArray = new Uint8Array(64);

    const draw = () => {
      timeRef.current += 0.02;
      const colors = getColors(accentHex, accentRgb)[state] || getColors(accentHex, accentRgb).idle;
      const analyser = analyserRef?.current;
      const hasAudio = !!analyser;

      if (hasAudio) {
        analyser.getByteFrequencyData(dataArray);
      }

      ctx.clearRect(0, 0, size, size);

      const cx = size / 2;
      const cy = size / 2;
      const coreRadius = size * 0.22;
      const innerRadius = size * 0.3;
      const maxBarLen = size * 0.22;

      let sum = 0;
      for (let i = 0; i < BAR_COUNT; i++) {
        let target;
        if (hasAudio) {
          // Bins baixos concentram a energia da voz humana
          const binIndex = Math.min(dataArray.length - 1, Math.floor((i / BAR_COUNT) * dataArray.length * 0.75) + 1);
          target = dataArray[binIndex] / 255;
        } else {
          // Sem áudio real (em espera / processando): animação orgânica só pra não ficar estático
          const speed = state === 'thinking' ? 3 : 1.2;
          const wobble = Math.sin(timeRef.current * speed + i * 0.4) * 0.5 + 0.5;
          target = wobble * (state === 'thinking' ? 0.5 : 0.3);
        }
        levelsRef.current[i] += (target - levelsRef.current[i]) * 0.28;
        sum += levelsRef.current[i];

        const angle = (i / BAR_COUNT) * Math.PI * 2 - Math.PI / 2;
        const len = maxBarLen * levelsRef.current[i];
        const x1 = cx + Math.cos(angle) * innerRadius;
        const y1 = cy + Math.sin(angle) * innerRadius;
        const x2 = cx + Math.cos(angle) * (innerRadius + len);
        const y2 = cy + Math.sin(angle) * (innerRadius + len);

        ctx.strokeStyle = `rgba(${colors.bar},${0.35 + levelsRef.current[i] * 0.6})`;
        ctx.lineWidth = Math.max(1.5, size * 0.018);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }

      const avg = sum / BAR_COUNT;

      // Núcleo central pulsando com o volume médio (RMS aproximado)
      ctx.save();
      ctx.shadowColor = colors.glow;
      ctx.shadowBlur = size * 0.25;
      ctx.beginPath();
      ctx.arc(cx, cy, coreRadius + avg * size * 0.1, 0, Math.PI * 2);
      ctx.fillStyle = colors.core;
      ctx.globalAlpha = 0.85;
      ctx.fill();
      ctx.restore();

      rafRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [state, analyserRef, size, accentHex, accentRgb]);

  return <canvas ref={canvasRef} style={{ width: size, height: size, display: 'block' }} />;
}
