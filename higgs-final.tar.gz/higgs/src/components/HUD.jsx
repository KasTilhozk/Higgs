import React, { useEffect, useRef, useState } from 'react';
import './HUD.css';

export default function HUD({ status, model, messageCount, aiState }) {
  const sessionStartRef = useRef(Date.now());
  const [uptimeSec, setUptimeSec] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setUptimeSec(Math.floor((Date.now() - sessionStartRef.current) / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatUptime = (totalSeconds) => {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    if (m === 0) return `${s}s`;
    return `${m}min`;
  };

  const stateLabel = {
    idle: 'em espera',
    listening: 'ouvindo',
    thinking: 'processando',
    speaking: 'respondendo',
  }[aiState] || 'em espera';

  const connectionLabel =
    status === 'online' ? 'conectado' : status === 'checking' ? 'verificando' : 'desconectado';

  return (
    <div className="status-bar">
      <div className="status-bar-group">
        <span className={`status-bar-dot-live ${aiState}`} />
        <span className="status-bar-item accent">{stateLabel}</span>
      </div>
      <span className="status-bar-sep" />
      <span className="status-bar-item dim">sessão · {formatUptime(uptimeSec)}</span>
      <span className="status-bar-sep" />
      <span className="status-bar-item dim">{model || '—'}</span>
      <span className="status-bar-sep" />
      <span className="status-bar-item dim">{messageCount} mensagens</span>
      <span className="status-bar-sep" />
      <span className={`status-bar-item ${status === 'online' ? 'ok' : 'warn'}`}>{connectionLabel}</span>
    </div>
  );
}
