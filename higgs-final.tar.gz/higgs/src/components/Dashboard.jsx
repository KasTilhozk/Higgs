import React, { useEffect, useState } from 'react';
import { Cpu, MemoryStick, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog, Sun, CloudSun, MapPin } from 'lucide-react';
import './Dashboard.css';

const WEEKDAYS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const MONTHS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

function greetingFor(hour) {
  if (hour < 6) return 'Boa madrugada';
  if (hour < 12) return 'Bom dia';
  if (hour < 18) return 'Boa tarde';
  return 'Boa noite';
}

function weatherIcon(code) {
  if (code === 0) return Sun;
  if ([1, 2].includes(code)) return CloudSun;
  if ([3, 45, 48].includes(code)) return CloudFog;
  if ([71, 73, 75, 77, 85, 86].includes(code)) return CloudSnow;
  if ([95, 96, 99].includes(code)) return CloudLightning;
  if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(code)) return CloudRain;
  return Cloud;
}

export default function Dashboard({ city, personality, onOpenSettings }) {
  const [now, setNow] = useState(new Date());
  const [weather, setWeather] = useState(null);
  const [weatherError, setWeatherError] = useState('');
  const [stats, setStats] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000 * 30);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!city) {
      setWeather(null);
      return;
    }
    let cancelled = false;
    const fetchWeather = async () => {
      const result = await window.electron.weather.get(city);
      if (cancelled) return;
      if (result?.error) {
        setWeatherError(result.error);
        setWeather(null);
      } else {
        setWeatherError('');
        setWeather(result);
      }
    };
    fetchWeather();
    const interval = setInterval(fetchWeather, 15 * 60 * 1000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [city]);

  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const result = await window.electron.system.stats();
      if (!cancelled) setStats(result);
    };
    poll();
    const interval = setInterval(poll, 4000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  const dateStr = `${WEEKDAYS[now.getDay()]}, ${now.getDate()} de ${MONTHS[now.getMonth()]}`;
  const timeStr = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const WeatherIcon = weather ? weatherIcon(weather.weatherCode) : Cloud;

  return (
    <div className="dashboard">
      <div className="dash-card clock-card">
        <div className="dash-clock">{timeStr}</div>
        <div className="dash-sub">{greetingFor(now.getHours())}{personality !== 'buddy' ? ', senhor' : ''}</div>
        <div className="dash-sub dim">{dateStr}</div>
      </div>

      <div className="dash-card weather-card">
        {city && weather ? (
          <>
            <WeatherIcon size={26} className="dash-weather-icon" />
            <div className="dash-weather-info">
              <div className="dash-temp">{weather.temp}°C</div>
              <div className="dash-sub dim">{weather.city} · {weather.description}</div>
            </div>
          </>
        ) : city && weatherError ? (
          <div className="dash-sub dim">{weatherError}</div>
        ) : (
          <button className="dash-empty-btn" onClick={onOpenSettings}>
            <MapPin size={14} /> Configurar cidade
          </button>
        )}
      </div>

      <div className="dash-card system-card">
        <div className="dash-metric">
          <Cpu size={15} />
          <div className="dash-bar">
            <div className="dash-bar-fill" style={{ width: `${stats?.cpuPercent ?? 0}%` }} />
          </div>
          <span className="dash-metric-value">{stats ? `${stats.cpuPercent}%` : '···'}</span>
        </div>
        <div className="dash-metric">
          <MemoryStick size={15} />
          <div className="dash-bar">
            <div className="dash-bar-fill" style={{ width: `${stats?.ramPercent ?? 0}%` }} />
          </div>
          <span className="dash-metric-value">{stats ? `${stats.ramPercent}%` : '···'}</span>
        </div>
      </div>
    </div>
  );
}
