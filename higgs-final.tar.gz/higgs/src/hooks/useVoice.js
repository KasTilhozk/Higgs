import { useEffect, useRef, useState } from 'react';

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export function useVoice() {
  const audioRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const streamRef = useRef(null);
  const audioCtxRef = useRef(null);

  // Refs (não state) para os analisadores de áudio: quem desenha (ReactorCore)
  // lê .current a cada frame de animação, sem precisar re-renderizar o App.
  const speakAnalyserRef = useRef(null);
  const micAnalyserRef = useRef(null);

  const [isListening, setIsListening] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    return () => {
      mediaRecorderRef.current?.stop();
      streamRef.current?.getTracks().forEach((t) => t.stop());
      audioRef.current?.pause();
      audioCtxRef.current?.close();
    };
  }, []);

  const ensureAudioContext = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  // Clique 1: começa a gravar. Clique 2 (ou chamada de stopListening): para e transcreve.
  const startListening = async (onResult, apiKey, onError) => {
    if (!apiKey) {
      onError?.('Configure a chave do Groq (gratuita) em Configurações para usar comando de voz.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];

      // Analisador do microfone em tempo real — conectado a um ganho mudo
      // (não à saída) para não causar eco, só pra alimentar o visualizador.
      try {
        const ctx = ensureAudioContext();
        const micSource = ctx.createMediaStreamSource(stream);
        const micAnalyser = ctx.createAnalyser();
        micAnalyser.fftSize = 128;
        micAnalyser.smoothingTimeConstant = 0.75;
        const silentGain = ctx.createGain();
        silentGain.gain.value = 0;
        micSource.connect(micAnalyser);
        micAnalyser.connect(silentGain);
        silentGain.connect(ctx.destination);
        micAnalyserRef.current = micAnalyser;
      } catch (e) {
        micAnalyserRef.current = null;
      }

      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        streamRef.current?.getTracks().forEach((t) => t.stop());
        micAnalyserRef.current = null;
        setIsListening(false);

        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        if (blob.size < 2000) return; // gravação vazia/muito curta, ignora

        setIsTranscribing(true);
        try {
          const base64 = await blobToBase64(blob);
          const { text } = await window.electron.stt.transcribe(base64, apiKey);
          if (text) onResult(text);
        } catch (err) {
          onError?.(err.message);
        } finally {
          setIsTranscribing(false);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsListening(true);
    } catch (err) {
      onError?.('Não foi possível acessar o microfone: ' + err.message);
    }
  };

  const stopListening = () => {
    if (mediaRecorderRef.current?.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  // Voz do navegador (fallback offline) — sem análise de áudio disponível
  const speakBrowser = (text, onEnd, volume = 1, lang = 'pt-BR') => {
    if (!('speechSynthesis' in window)) {
      onEnd?.();
      return;
    }
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'en' ? 'en-US' : 'pt-BR';
    utterance.rate = 0.98;
    utterance.volume = volume;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => {
      setIsSpeaking(false);
      onEnd?.();
    };
    utterance.onerror = () => {
      setIsSpeaking(false);
      onEnd?.();
    };
    speechSynthesis.speak(utterance);
  };

  // Voz neural (Microsoft Edge Read Aloud) — ligada a um analisador real,
  // então o núcleo visual reage à própria voz do JARVIS enquanto ele fala.
  const speak = async (text, options = {}, onEnd) => {
    if (!text) {
      onEnd?.();
      return;
    }
    const volume = options.volume ?? 1;
    if (!window.electron?.tts) {
      speakBrowser(text, onEnd, volume, options.language);
      return;
    }
    try {
      const { audioBase64 } = await window.electron.tts.speak(
        text,
        options.voice || 'pt-BR-AntonioNeural',
        options.rate || '+0%',
        options.pitch || '-8%'
      );
      audioRef.current?.pause();
      const audio = new Audio(`data:audio/mp3;base64,${audioBase64}`);
      audio.volume = volume;
      audioRef.current = audio;

      try {
        const ctx = ensureAudioContext();
        const source = ctx.createMediaElementSource(audio);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        analyser.smoothingTimeConstant = 0.8;
        source.connect(analyser);
        analyser.connect(ctx.destination);
        speakAnalyserRef.current = analyser;
      } catch (e) {
        speakAnalyserRef.current = null;
      }

      audio.onplay = () => setIsSpeaking(true);
      audio.onended = () => {
        setIsSpeaking(false);
        speakAnalyserRef.current = null;
        onEnd?.();
      };
      audio.onerror = () => {
        setIsSpeaking(false);
        speakAnalyserRef.current = null;
        onEnd?.();
      };

      await audio.play();
    } catch (error) {
      console.warn('Voz neural indisponível, usando voz do sistema:', error.message);
      speakBrowser(text, onEnd, volume, options.language);
    }
  };

  const stopSpeaking = () => {
    audioRef.current?.pause();
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  return {
    isListening,
    isTranscribing,
    isSpeaking,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    speakAnalyserRef,
    micAnalyserRef,
  };
}
